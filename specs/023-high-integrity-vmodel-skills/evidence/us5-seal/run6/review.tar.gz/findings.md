# Inspection findings

Standard profile: **Generic high-integrity baseline** (`generic`), integrity level **HI-2**.

## sys-req: System requirements

| Id | Phase | Round | Item | Checklist | Severity | Status | Description |
|---|---|---|---|---|---|---|---|
| F-sys-req-item-r1-001 | item | 1 | SYS-SUP-002 | IQ-09 | blocking | resolved | Detection at the instant the start limit expires conflicts with SYS-SUP-005 and CON-SUP-127, which treat a start delay equal to the limit as valid and allow detection up to 100 µs after expiry. |
| F-sys-req-item-r1-002 | item | 1 | SYS-SUP-003 | IQ-09 | blocking | resolved | Detecting an overrun at the instant the execution limit expires conflicts with SYS-SUP-005 and CON-SUP-127, which permit execution exactly equal to the limit and allow detection up to 100 µs after expiry. |
| F-sys-req-item-r1-003 | item | 1 | SYS-SUP-018 | IQ-04 | major | resolved | The configuration CRC is stored in the same block over which the CRC is computed, but CON-SUP-107 and CON-SUP-129 do not identify whether the stored reference bytes are excluded or how they participate in the computation. |
| F-sys-req-item-r1-004 | item | 1 | SYS-SUP-021 | IQ-04 | major | resolved | The requirement calls for one 1 KiB segment per cycle, while CON-SUP-107 permits an image of at most 1 MiB without requiring its size to be a multiple of 1 KiB. The final partial segment is unspecified. |
| F-sys-req-item-r1-005 | item | 1 | SYS-SUP-028 | IQ-09 | blocking | resolved | The requirement unconditionally drives the status high when start-up checks pass, including when the safe-state latch is set. CON-SUP-117 requires the safe state to remain latched until power-on reset, and CON-SUP-109 defines low as not operational. |
| F-sys-req-item-r1-006 | item | 1 | SYS-SUP-029 | IQ-09 | blocking | resolved | The reset obligation applies to any first or second detection, but CON-SUP-115 requires code 9 to latch the safe state, and CON-SUP-130 and CON-SUP-137 treat a code 8 start-up report as a latch-count event without initiating the normal fault reaction. |
| F-sys-req-item-r1-007 | item | 1 | SYS-SUP-030 | IQ-09 | blocking | resolved | The requirement applies the normal third-detection reaction to every fault code, while CON-SUP-130 says a code 8 start-up report does not by itself enter the safe state and start-up continues. CON-SUP-115 also latches code 9 on its first detection. |
| F-sys-req-item-r1-008 | item | 1 | SYS-SUP-030 | IQ-05 | major | resolved | Safe-state entry, transmission of a report, suppression of a reset and retention of the latch are independently judgeable obligations; one can succeed while another fails. |
| F-sys-req-item-r1-009 | item | 1 | SYS-SUP-039 | IQ-09 | blocking | resolved | The unconditional report within 10 ms conflicts with CON-SUP-121, which permits a watchdog reset to interrupt fault handling and requires only the subsequent code 8 report, with no report for the interrupted fault. |
| F-sys-req-item-r1-010 | item | 1 | SYS-SUP-043 | IQ-03 | major | resolved | CON-SUP-139 gives fault reports priority over service answers, but the requirement does not define what happens when an answer is already being transmitted. Different interpretations could interrupt a line or wait for its completion. |
| F-sys-req-item-r1-011 | item | 1 | SYS-SUP-038 | IQ-09 | blocking | resolved | The unconditional answer within 50 ms conflicts with CON-SUP-139 and SYS-SUP-050 and SYS-SUP-063: a request received during an answer is ignored, and intervening fault-report transmission extends the deadline. |
| F-sys-req-item-r1-012 | item | 1 | SYS-SUP-045 | IQ-09 | blocking | resolved | The unconditional answer within 50 ms conflicts with CON-SUP-139 and SYS-SUP-050 and SYS-SUP-063: a request received during an answer is ignored, and intervening fault-report transmission extends the deadline. |
| F-sys-req-item-r1-013 | item | 1 | SYS-SUP-046 | IQ-09 | blocking | resolved | The requirement reports SAFE from any fault detection until reset, while CON-SUP-130 and CON-SUP-137 say a code 8 report at start-up does not by itself enter the safe state and start-up continues. |
| F-sys-req-item-r1-014 | item | 1 | SYS-SUP-048 | IQ-09 | blocking | resolved | The unconditional answer within 50 ms conflicts with CON-SUP-139 and SYS-SUP-050 and SYS-SUP-063: a request received during an answer is ignored, and intervening fault-report transmission extends the deadline. |
| F-sys-req-item-r1-015 | item | 1 | SYS-SUP-049 | IQ-09 | blocking | resolved | The unconditional ERR response conflicts with CON-SUP-139 and SYS-SUP-050 when the invalid or overlong request is received while another answer is being transmitted. |
| F-sys-req-item-r1-016 | item | 1 | SYS-SUP-059 | IQ-09 | blocking | resolved | The count may be returned to zero only after 60 s of fault-free operation, but SYS-SUP-060 requires it to be cleared at any power-on reset, including before 60 s has elapsed. |
| F-sys-req-item-r1-017 | item | 1 | SYS-SUP-063 | IQ-09 | blocking | resolved | The requirement mandates an answer to every service request, but CON-SUP-139 and SYS-SUP-050 require a request received while an answer is being transmitted to be ignored. |
| F-sys-req-item-r2-001 | item | 2 | SYS-SUP-018 | IQ-06 | blocking | resolved | The requirement leaves the configuration bytes covered by the CRC and the treatment of the stored reference undecided. CON-SUP-107 and CON-SUP-129 do not resolve them, so a verifier cannot determine the expected CRC for a configuration block. |
| F-sys-req-item-r2-002 | item | 2 | SYS-SUP-021 | IQ-04 | major | resolved | The requirement calls for a CRC over one segment per cycle but does not specify how segments cover the image or how their results form the full-image CRC used by SYS-SUP-023. Rechecking one segment or independently calculating segment CRCs can satisfy the stated segment behavior without checking the full image. |
| F-sys-req-item-r2-003 | item | 2 | SYS-SUP-043 | IQ-04 | blocking | resolved | The requirement explicitly leaves fault-report priority undecided when a service answer is already being transmitted. CON-SUP-139 gives fault reports priority, and CON-SUP-112 requires a report within 10 ms; the required line behavior for this case is therefore incomplete. |
| F-sys-req-item-r2-004 | item | 2 | SYS-SUP-046 | IQ-05 | major | resolved | The statement combines independently testable reporting obligations for STARTUP, OPERATIONAL, SAFE and LATCHED with the separate obligation to count a code 8 report toward the latch rule. One state or the counting behavior could fail while the others pass. |
| F-sys-req-item-r2-005 | item | 2 | SYS-SUP-059 | IQ-04 | major | resolved | The phrase 'only after 60 s' prohibits an early count reset but permits the count never to be reset. CON-SUP-117 and CON-SUP-140 require the latch decision to distinguish detections separated by 60 s of fault-free operation, which cannot be assured if an old count persists indefinitely. |
| F-sys-req-item-r3-001 | item | 3 | SYS-SUP-046 | IQ-09 | blocking | resolved | The requirement reports STARTUP from any reset until the start-up checks pass, even if a fault is detected during start-up or the latch is set. SYS-SUP-068 and SYS-SUP-069 require SAFE and LATCHED respectively in those cases; CON-SUP-130 gives LATCHED priority. |
| F-sys-req-item-r3-002 | item | 3 | SYS-SUP-059 | IQ-02 | blocking | resolved | The requirement clears a code's count after 60 s of OPERATIONAL time since that code's most recent detection. CON-SUP-140 requires 60 s of fault-free operation, so a detection of a different code during that interval prevents it from being fault-free. CON-SUP-136 also permits bounded under-counting, whereas the requirement demands clearing exactly when 60 s have accumulated. |
| F-sys-req-item-r3-003 | item | 3 | SYS-SUP-066 | IQ-08 | major | resolved | The requirement mandates carrying a running CRC value from each segment to the next. CON-SUP-108 requires segmented processing and CON-SUP-129 defines the resulting CRC, but neither requires that intermediate computation method; the same whole-range result could be obtained by another method. |
| F-sys-req-set-r1-001 | set | 1 | SYS-SUP-018 | IQ-06 | blocking | resolved | SYS-SUP-018 leaves the configuration bytes covered by the CRC and the treatment of the stored reference undecided. CON-SUP-107 and CON-SUP-129 do not resolve them, so a verifier cannot determine the expected CRC for a configuration block. |
| F-sys-req-set-r1-002 | set | 1 | SYS-SUP-043 | IQ-04 | blocking | resolved | SYS-SUP-043 leaves fault-report priority undecided when a service answer is already being transmitted. CON-SUP-139 gives fault reports priority, and CON-SUP-112 requires a report within 10 ms; the line behavior for this case is incomplete. |
| F-sys-req-set-r1-003 | set | 1 | SET | SQ-02 | blocking | resolved | CON-SUP-117 requires the safe-state latch to hold the safe state until power-on reset. SYS-SUP-030 and SYS-SUP-065 set the latch, but the set does not require the outputs and status to remain low while it is set or prevent task release after checks pass. SYS-SUP-026 only holds outputs low until the checks pass. |
| F-sys-req-set-r1-004 | set | 1 | SET | SQ-01 | blocking | resolved | CON-SUP-132 specifies external pull-down resistors holding the three signals low and microcontroller pins remaining inputs until software configures them. SYS-SUP-026 requires low outputs and SYS-SUP-027 requires subsequent configuration, but the set does not capture the specified board provision or pin state during that interval. |
| F-sys-req-set-r1-005 | set | 1 | SET | SQ-01 | blocking | resolved | CON-SUP-112 requires fault reports within 10 ms, and CON-SUP-141 identifies the classification instant for a code 8 report. SYS-SUP-039 applies its deadline when a fault is detected, but CON-SUP-137 says a code 8 report at start-up is not a fault detection; SYS-SUP-034 requires the report without a time limit. |
| F-sys-req-set-r2-001 | set | 2 | SYS-SUP-018 | IQ-06 | blocking | resolved | SYS-SUP-018 leaves the configuration bytes covered by the CRC and the treatment of the stored reference undecided. CON-SUP-107 and CON-SUP-129 do not resolve them, so a verifier cannot determine the expected CRC for a configuration block. |
| F-sys-req-set-r2-002 | set | 2 | SYS-SUP-043 | IQ-04 | blocking | resolved | SYS-SUP-043 leaves fault-report priority undecided when a service answer is already being transmitted. CON-SUP-139 gives fault reports priority, and CON-SUP-112 requires a report within 10 ms; the line behavior for this case is incomplete. |
| F-sys-req-set-r2-003 | set | 2 | SET | SQ-01 | blocking | resolved | CON-SUP-112 requires fault reports within 10 ms, but SYS-SUP-034 requires a code 8 report without a time limit. CON-SUP-137 says that report is not a fault detection, and CON-SUP-141 identifies its timestamp but does not settle the transmission deadline. |
| F-sys-req-set-r2-004 | set | 2 | SET | SQ-01 | blocking | resolved | CON-SUP-113 requires GET FAULTS to return the last eight fault reports. SYS-SUP-048 returns up to eight reports held in oldest-first order, but the set does not require the held reports to be the most recent eight. |
| F-sys-req-set-r3-001 | set | 3 | SYS-SUP-018 | IQ-06 | blocking | resolved | SYS-SUP-018 leaves the configuration bytes covered by the CRC and the treatment of the stored reference undecided. CON-SUP-107 and CON-SUP-129 do not resolve them, so a verifier cannot determine the expected CRC for a configuration block. |
| F-sys-req-set-r3-002 | set | 3 | SYS-SUP-043 | IQ-04 | blocking | resolved | SYS-SUP-043 leaves fault-report priority undecided when a service answer is already being transmitted. CON-SUP-139 gives fault reports priority, and CON-SUP-112 requires a report within 10 ms; the line behavior for this case is incomplete. |
| F-sys-req-set-r3-003 | set | 3 | SET | SQ-01 | blocking | resolved | CON-SUP-112 requires fault reports within 10 ms, but SYS-SUP-034 requires a code 8 report without a time limit. CON-SUP-137 says that report is not a fault detection, and CON-SUP-141 identifies its timestamp but does not settle the transmission deadline. |
| F-sys-req-set-r3-004 | set | 3 | SET | SQ-01 | blocking | resolved | CON-SUP-112 specifies the FLT line format for fault reports, including code 8. SYS-SUP-034 requires a code 8 report, but SYS-SUP-039 requires the FLT format only when a fault is detected; CON-SUP-137 says the code 8 report is not a fault detection. |
| F-sys-req-set-r4-001 | set | 4 | SYS-SUP-018 | IQ-06 | blocking | resolved | SYS-SUP-018 leaves the configuration bytes covered by the CRC and the treatment of the stored reference undecided. CON-SUP-107 and CON-SUP-129 do not resolve them, so the expected CRC for a configuration block cannot be determined. |
| F-sys-req-set-r4-002 | set | 4 | SYS-SUP-043 | IQ-04 | blocking | resolved | SYS-SUP-043 leaves fault-report priority undecided when a service answer is already being transmitted. CON-SUP-139 gives fault reports priority, while CON-SUP-112 requires a report within 10 ms; the line behavior in this case remains unresolved. |
| F-sys-req-set-r4-003 | set | 4 | SET | SQ-01 | blocking | resolved | SYS-SUP-034 requires a code 8 report without a transmission deadline. CON-SUP-112 specifies a 10 ms deadline from detection, but CON-SUP-137 says a code 8 report is not a fault detection; CON-SUP-141 specifies its timestamp without settling the deadline. |
| F-sys-req-item-r5-001 | item | 5 | SYS-SUP-013 | IQ-09 | blocking | resolved | The requirement mandates window-watchdog refresh while every supervised task is healthy, including when a non-task fault such as a code-integrity fault has been detected. SYS-SUP-010 and CON-SUP-121 prohibit watchdog servicing from fault detection until reset. |
| F-sys-req-item-r5-002 | item | 5 | SYS-SUP-014 | IQ-09 | blocking | resolved | The requirement mandates independent-watchdog servicing while every supervised task is healthy, including when a non-task fault has been detected. SYS-SUP-010 and CON-SUP-121 prohibit watchdog servicing from fault detection until reset. |
| F-sys-req-item-r5-003 | item | 5 | SYS-SUP-037 | IQ-06 | blocking | resolved | The requirement gives no deadline for sending the reset-cause message after classification. A verifier observing that no message has arrived cannot determine when the requirement has failed. OP-SYS-001 defers this missing limit even though it is needed to verify the obligation. |
| F-sys-req-item-r5-004 | item | 5 | SYS-SUP-006 | IQ-05 | major | resolved | The default task set, release order, start limits and execution limits are independently judgeable: for example, the task set can be correct while an execution limit is wrong. |
| F-sys-req-item-r5-005 | item | 5 | SYS-SUP-048 | IQ-05 | major | resolved | The answer deadline, selection and ordering of reports, END termination, empty-history response and replacement of the oldest stored report can fail independently, but are combined in one obligation. |
| F-sys-req-item-r6-001 | item | 6 | SYS-SUP-081 | IQ-03 | major | resolved | The requirement does not say when the most recent eight reports are selected. CON-SUP-143 permits a new fault report to be transmitted between lines of a GET FAULTS answer, so the history can change while the answer is being sent. |
| F-sys-req-item-r7-001 | item | 7 | SYS-SUP-081 | IQ-09 | blocking | resolved | SYS-SUP-081 requires an answer whenever GET FAULTS is received. CON-SUP-139 and SYS-SUP-050 require a request received while an answer is being transmitted to be ignored without an answer. |
| F-sys-req-set-r5-001 | set | 5 | SYS-SUP-037 | IQ-06 | blocking | resolved | The requirement gives no deadline for sending the reset-cause message after classification. OP-SYS-001 defers the missing limit, but an observer cannot determine when the obligation has failed. |
| F-sys-req-set-r5-002 | set | 5 | SET | SQ-01 | blocking | resolved | CON-SUP-133 limits the board output stage to 1 ms from pin change to output level. SYS-SUP-025 specifies the 49 ms software allocation, and SYS-SUP-024 specifies the overall 50 ms reaction, but the set does not state the intervening board output-stage limit. |
| F-sys-req-set-r5-003 | set | 5 | SET | SQ-01 | blocking | resolved | CON-SUP-103 specifies 100 µs measurement resolution for task timing. SYS-SUP-002, SYS-SUP-003 and SYS-SUP-056 specify detection deadlines, but the set does not require that measurement resolution. |
| F-sys-req-set-r5-004 | set | 5 | SET | SQ-01 | blocking | resolved | The system requirement set does not capture or disposition the target microcontroller in CON-SUP-001 or the C11, no dynamic allocation and no recursion constraints in CON-SUP-004. These constraints are needed by downstream engineering. |
| F-sys-req-set-r5-005 | set | 5 | SET | SQ-01 | major | resolved | Coverage partial: STK-SUP-002 - CON-SUP-103 measurement resolution is missing; see the SQ-01 finding for timing resolution. |
| F-sys-req-set-r5-006 | set | 5 | SET | SQ-01 | major | resolved | Coverage partial: STK-SUP-009 - The allocated board output-stage limit is missing; see the SQ-01 finding for CON-SUP-133. |
| F-sys-req-set-r5-007 | set | 5 | SET | SQ-01 | major | resolved | Coverage partial: STK-SUP-011 - The start-up reset-cause message lacks a deadline; OP-SYS-001 and the IQ-06 finding track it. |
| F-sys-req-set-r5-008 | set | 5 | SET | SQ-01 | major | resolved | Coverage partial: UC-SUP-001 - CON-SUP-103 measurement resolution is missing; see the SQ-01 finding for timing resolution. |
| F-sys-req-set-r5-009 | set | 5 | SET | SQ-01 | major | resolved | Coverage partial: UC-SUP-006 - The allocated board output-stage limit is missing; see the SQ-01 finding for CON-SUP-133. |
| F-sys-req-set-r5-010 | set | 5 | SET | SQ-01 | major | resolved | Coverage partial: UC-SUP-008 - The start-up reset-cause message lacks a deadline; OP-SYS-001 and the IQ-06 finding track it. |
| F-sys-req-set-r5-011 | set | 5 | SET | SQ-01 | major | resolved | Coverage partial: needs/constraints.md: platform constraints CON-SUP-001..007 - CON-SUP-001 and CON-SUP-004 are not captured or dispositioned in the system baseline; see the SQ-01 finding for platform and implementation constraints. |
| F-sys-req-set-r5-012 | set | 5 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: initial decisions CON-SUP-101..116 - CON-SUP-103 measurement resolution is missing; the CON-SUP-111 start-up message deadline is unresolved. See the corresponding SQ-01 and IQ-06 findings and OP-SYS-001. |
| F-sys-req-set-r5-013 | set | 5 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: seventh round CON-SUP-131..135 - CON-SUP-133's 1 ms board output-stage limit is missing; see the SQ-01 finding for that constraint. |
| F-sys-req-set-r5-014 | set | 5 | SET | SQ-01 | major | resolved | Coverage partial: normal operation - CON-SUP-103 measurement resolution is missing; see the SQ-01 finding for timing resolution. |
| F-sys-req-set-r5-015 | set | 5 | SET | SQ-01 | major | resolved | Coverage partial: fault detection and reaction - CON-SUP-103 measurement resolution and CON-SUP-133 board output-stage limit are missing; see the two corresponding SQ-01 findings. |
| F-sys-req-set-r5-016 | set | 5 | SET | SQ-01 | major | resolved | Coverage partial: recovery or reset - The start-up reset-cause message lacks a deadline; OP-SYS-001 and the IQ-06 finding track it. |
| F-sys-req-set-r5-017 | set | 5 | SET | SQ-01 | major | resolved | Coverage partial: non-functional limits - The timing measurement resolution and board output-stage limit are missing, and the reset-cause message deadline is unresolved; see the corresponding findings and OP-SYS-001. |
| F-sys-req-set-r6-001 | set | 6 | SYS-SUP-037 | IQ-06 | blocking | resolved | The requirement has no deadline for sending the reset-cause start-up message after classification. OP-SYS-001 defers that deadline, so an observer cannot determine when the obligation has failed. |
| F-sys-req-set-r6-002 | set | 6 | SET | SQ-01 | blocking | resolved | CON-SUP-124 places the program CRC reference outside the checked application range. SYS-SUP-016 identifies the reference and range but does not state that separation. CON-SUP-107 also limits the application image to 1 MiB; SYS-SUP-058 specifies a check time for a 1 MiB image but does not limit the image size. |
| F-sys-req-set-r6-003 | set | 6 | SET | SQ-01 | major | resolved | Coverage partial: STK-SUP-007 - Program CRC reference placement and the maximum image size are missing; see the SQ-01 finding. |
| F-sys-req-set-r6-004 | set | 6 | SET | SQ-01 | major | resolved | Coverage partial: STK-SUP-008 - The maximum application image size is not stated; see the SQ-01 finding. |
| F-sys-req-set-r6-005 | set | 6 | SET | SQ-01 | major | resolved | Coverage partial: STK-SUP-011 - The start-up reset-cause message lacks a deadline; see OP-SYS-001 and the IQ-06 finding. |
| F-sys-req-set-r6-006 | set | 6 | SET | SQ-01 | major | resolved | Coverage partial: UC-SUP-004 - Program CRC reference placement and the maximum image size are missing; see the SQ-01 finding. |
| F-sys-req-set-r6-007 | set | 6 | SET | SQ-01 | major | resolved | Coverage partial: UC-SUP-005 - The maximum application image size is not stated; see the SQ-01 finding. |
| F-sys-req-set-r6-008 | set | 6 | SET | SQ-01 | major | resolved | Coverage partial: UC-SUP-008 - The start-up reset-cause message lacks a deadline; see OP-SYS-001 and the IQ-06 finding. |
| F-sys-req-set-r6-009 | set | 6 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: initial decisions CON-SUP-101..116 - The maximum application image size is missing, and the start-up message deadline remains unresolved; see the SQ-01 finding, OP-SYS-001 and the IQ-06 finding. |
| F-sys-req-set-r6-010 | set | 6 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: fifth round CON-SUP-124..128 - The program CRC reference is not required to be outside the checked range; see the SQ-01 finding. |
| F-sys-req-set-r6-011 | set | 6 | SET | SQ-01 | major | resolved | Coverage partial: normal operation - The maximum application image size is not stated; see the SQ-01 finding. |
| F-sys-req-set-r6-012 | set | 6 | SET | SQ-01 | major | resolved | Coverage partial: recovery or reset - The start-up reset-cause message lacks a deadline; see OP-SYS-001 and the IQ-06 finding. |
| F-sys-req-set-r6-013 | set | 6 | SET | SQ-01 | major | resolved | Coverage partial: non-functional limits - The maximum application image size and reset-cause message deadline are unresolved; see the SQ-01 and IQ-06 findings and OP-SYS-001. |
| F-sys-req-set-r7-001 | set | 7 | SYS-SUP-037 | IQ-06 | blocking | resolved | SYS-SUP-037 requires a start-up reset-cause message after classification but gives no deadline. An observer cannot determine when the obligation has failed. OP-SYS-001 defers the missing deadline to software requirements. |
| F-sys-req-set-r7-002 | set | 7 | SET | SQ-05 | blocking | resolved | SYS-SUP-029, SYS-SUP-030, SYS-SUP-064 and SYS-SUP-065 condition the response on there being no 60 s of fault-free operation since the first detection. SYS-SUP-059 clears a count only after 60 s since the most recent detection of any code. Detections at 0, 59 and 118 seconds can therefore leave the count at three while failing the third-detection condition, contrary to CON-SUP-140. |
| F-sys-req-set-r7-003 | set | 7 | SET | SQ-05 | blocking | resolved | SYS-SUP-061 prohibits entering the safe state because of a code 8 report, while SYS-SUP-065 sets the latch on the third code 8 report and SYS-SUP-070 holds the outputs in the safe state while latched. CON-SUP-130 says the report does not by itself enter the safe state, but also counts toward the latch rule. |
| F-sys-req-set-r7-004 | set | 7 | SET | SQ-01 | major | resolved | Coverage partial: STK-SUP-010 - The latch and reset conditions conflict with the count-clearing rule; code 8 safe-state obligations also conflict. See the SQ-05 findings. |
| F-sys-req-set-r7-005 | set | 7 | SET | SQ-01 | major | resolved | Coverage partial: STK-SUP-011 - The start-up reset-cause message has no deadline. See OP-SYS-001 and the IQ-06 finding. |
| F-sys-req-set-r7-006 | set | 7 | SET | SQ-01 | major | resolved | Coverage partial: UC-SUP-007 - The latch and reset conditions conflict with the count-clearing rule; code 8 safe-state obligations also conflict. See the SQ-05 findings. |
| F-sys-req-set-r7-007 | set | 7 | SET | SQ-01 | major | resolved | Coverage partial: UC-SUP-008 - The start-up reset-cause message has no deadline. See OP-SYS-001 and the IQ-06 finding. |
| F-sys-req-set-r7-008 | set | 7 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: initial decisions CON-SUP-101..116 - The reset-cause message deadline is unresolved; the recovery and latch conditions conflict. See OP-SYS-001 and the IQ-06 and SQ-05 findings. |
| F-sys-req-set-r7-009 | set | 7 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: second round CON-SUP-117..120 - The latch and reset conditions conflict with the count-clearing rule. See the SQ-05 finding. |
| F-sys-req-set-r7-010 | set | 7 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: sixth round CON-SUP-129..130 - The code 8 report and third-detection latch have conflicting safe-state obligations. See the SQ-05 finding. |
| F-sys-req-set-r7-011 | set | 7 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: seventh round CON-SUP-131..135 - The latch conditions do not consistently use the fault-free interval tracked by SYS-SUP-059. See the SQ-05 finding. |
| F-sys-req-set-r7-012 | set | 7 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: ninth round CON-SUP-137..138 - The code 8 report and third-detection latch have conflicting safe-state obligations. See the SQ-05 finding. |
| F-sys-req-set-r7-013 | set | 7 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: tenth round CON-SUP-139..140 - The reset and latch conditions conflict with the per-code count and clearing rule. See the SQ-05 finding. |
| F-sys-req-set-r7-014 | set | 7 | SET | SQ-01 | major | resolved | Coverage partial: recovery or reset - The start-up message deadline is unresolved, and the reset and latch obligations conflict. See OP-SYS-001 and the IQ-06 and SQ-05 findings. |
| F-sys-req-set-r7-015 | set | 7 | SET | SQ-01 | major | resolved | Coverage partial: non-functional limits - The start-up reset-cause message deadline remains unresolved. See OP-SYS-001 and the IQ-06 finding. |
| F-sys-req-set-r8-001 | set | 8 | SYS-SUP-037 | IQ-06 | blocking | resolved | SYS-SUP-037 requires a start-up reset-cause message after classification but gives no deadline. An observer cannot determine when the obligation has failed. OP-SYS-001 defers the missing deadline to software requirements. |
| F-sys-req-set-r8-002 | set | 8 | SET | SQ-01 | major | resolved | Coverage partial: STK-SUP-011 - The start-up reset-cause message has no deadline; see OP-SYS-001 and the IQ-06 finding. |
| F-sys-req-set-r8-003 | set | 8 | SET | SQ-01 | major | resolved | Coverage partial: UC-SUP-008 - The start-up reset-cause message has no deadline; see OP-SYS-001 and the IQ-06 finding. |
| F-sys-req-set-r8-004 | set | 8 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: initial decisions CON-SUP-101..116 - The reset-cause message deadline is unresolved; see OP-SYS-001 and the IQ-06 finding. |
| F-sys-req-set-r8-005 | set | 8 | SET | SQ-01 | major | resolved | Coverage partial: recovery or reset - The start-up reset-cause message has no deadline; see OP-SYS-001 and the IQ-06 finding. |
| F-sys-req-set-r8-006 | set | 8 | SET | SQ-01 | major | resolved | Coverage partial: non-functional limits - The start-up reset-cause message deadline remains unresolved; see OP-SYS-001 and the IQ-06 finding. |
| F-sys-req-set-r9-001 | set | 9 | SYS-SUP-037 | IQ-06 | blocking | resolved | SYS-SUP-037 requires a start-up reset-cause message after classification but states no deadline. CON-SUP-111 also gives no deadline, so lateness cannot be verified. OP-SYS-001 now correctly records this as a blocking decision. |
| F-sys-req-set-r9-002 | set | 9 | SET | SQ-01 | major | resolved | Coverage of STK-SUP-011 is partial because the reset-cause start-up message has no deadline. OP-SYS-001 tracks the missing decision. |
| F-sys-req-set-r9-003 | set | 9 | SET | SQ-01 | major | resolved | Coverage of UC-SUP-008 is partial because the reset-cause start-up message has no deadline. OP-SYS-001 tracks the missing decision. |
| F-sys-req-set-r9-004 | set | 9 | SET | SQ-01 | major | resolved | Coverage of the initial product decisions is partial: CON-SUP-111 requires a start-up reset-cause message, but its deadline is unresolved in OP-SYS-001. |
| F-sys-req-set-r9-005 | set | 9 | SET | SQ-01 | major | resolved | Recovery and reset coverage is partial because the start-up reset-cause message has no deadline. OP-SYS-001 tracks the missing decision. |
| F-sys-req-set-r9-006 | set | 9 | SET | SQ-01 | major | resolved | Non-functional limits are partial because the start-up reset-cause message deadline remains unresolved in OP-SYS-001. |
| F-sys-req-set-r9-007 | set | 9 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: initial decisions CON-SUP-101..116 - CON-SUP-111 requires a start-up message whose deadline is unresolved; see OP-SYS-001. |
| F-sys-req-set-r9-008 | set | 9 | SET | SQ-01 | major | resolved | Coverage partial: recovery or reset - The start-up reset-cause message has no deadline; OP-SYS-001 tracks the missing decision. |
| F-sys-req-set-r9-009 | set | 9 | SET | SQ-01 | major | resolved | Coverage partial: non-functional limits - The start-up reset-cause message deadline remains unresolved; OP-SYS-001 tracks the missing decision. |
| F-sys-req-set-r10-001 | set | 10 | SYS-SUP-037 | IQ-06 | blocking | resolved | SYS-SUP-037 requires a start-up reset-cause message after classification but gives no deadline. CON-SUP-111 does not supply one, so lateness cannot be assessed. OP-SYS-001 records the missing acceptance limit. |
| F-sys-req-set-r10-002 | set | 10 | SET | SQ-01 | major | resolved | Coverage of STK-SUP-011, UC-SUP-008, CON-SUP-111, start-up, recovery or reset, and non-functional limits is partial because the reset-cause start-up message has no deadline. OP-SYS-001 tracks the decision. This combines the carried set findings that describe the same gap. |
| F-sys-req-set-r10-003 | set | 10 | SET | SQ-10 | major | resolved | CON-SUP-127 specifies verification margins of at least 200 µs on either side of a timing limit. SYS-SUP-002, SYS-SUP-003, SYS-SUP-005 and SYS-SUP-056 state the timing behavior but the set does not record those verification margins. |
| F-sys-req-set-r10-004 | set | 10 | SET | SQ-01 | major | resolved | Coverage partial: STK-SUP-002 - The timing behavior is specified, but the CON-SUP-127 verification margins are not recorded; see the SQ-10 finding. |
| F-sys-req-set-r10-005 | set | 10 | SET | SQ-01 | major | resolved | Coverage partial: UC-SUP-001 - The timing-limit verification margins are missing; see the SQ-10 finding. |
| F-sys-req-set-r10-006 | set | 10 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: initial decisions CON-SUP-101..116 - The CON-SUP-111 start-up message deadline is unresolved in OP-SYS-001; later decisions amend several initial decisions. |
| F-sys-req-set-r10-007 | set | 10 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: fifth round CON-SUP-124..128 - CON-SUP-127's specified verification margins are not recorded; see the SQ-10 finding. |
| F-sys-req-set-r10-008 | set | 10 | SET | SQ-01 | major | resolved | Coverage partial: normal operation - The CON-SUP-127 timing-limit verification margins are missing; see the SQ-10 finding. |
| F-sys-req-set-r10-009 | set | 10 | SET | SQ-01 | major | resolved | Coverage partial: fault detection and reaction - The CON-SUP-127 timing-limit verification margins are missing; see the SQ-10 finding. |
| F-sys-req-item-r9-001 | item | 9 | SYS-SUP-016 | IQ-03 | major | resolved | The checked range is stated as from __app_start to __app_end, but neither the requirement nor CON-SUP-107 defines whether the byte at __app_end is included. Different interpretations produce different CRC values. |
| F-sys-req-item-r9-002 | item | 9 | SYS-SUP-029 | IQ-02 | blocking | resolved | The reset obligation has no exception for a watchdog reset interrupting fault handling. CON-SUP-121 permits that reset before the original report and safe-state entry complete and requires no original fault report; SYS-SUP-039 reflects that exception, leaving the deadline in SYS-SUP-029 without its stated starting event. |
| F-sys-req-item-r9-003 | item | 9 | SYS-SUP-085 | IQ-05 | major | resolved | The requirement combines measurement of start delay and execution time at 100 µs resolution. One measurement can meet that resolution while the other fails, so the two obligations are independently judgeable. |
| F-sys-req-item-r10-001 | item | 10 | SYS-SUP-016 | IQ-03 | blocking | resolved | The CRC range is stated as from __app_start to __app_end, but CON-SUP-107, CON-SUP-124 and CON-SUP-129 do not say whether the byte at __app_end is included. The two interpretations produce different CRC inputs, so the requirement cannot be verified consistently. |
| F-sys-req-set-r11-001 | set | 11 | SYS-SUP-016 | IQ-03 | blocking | resolved | CON-SUP-107, CON-SUP-124 and CON-SUP-129 do not establish whether the byte at __app_end is included in the CRC input. SYS-SUP-016 therefore admits different CRC inputs. |
| F-sys-req-set-r11-002 | set | 11 | SYS-SUP-018 | IQ-03 | blocking | resolved | CON-SUP-142 defines the configuration CRC range using __cfg_start and __cfg_end but does not establish whether the byte at __cfg_end is included. SYS-SUP-018 therefore admits different CRC inputs. OP-SYS-004 addresses the application range, not the configuration range. |
| F-sys-req-set-r11-003 | set | 11 | SET | SQ-10 | major | resolved | CON-SUP-127 specifies verification margins of at least 200 µs on either side of a timing limit. SYS-SUP-002, SYS-SUP-003, SYS-SUP-005 and SYS-SUP-056 state the timing behavior, but the set does not record those verification margins. |
| F-sys-req-set-r11-004 | set | 11 | SET | SQ-01 | major | resolved | Coverage partial: needs/product-decisions.md: twelfth round CON-SUP-142..144 - The configuration CRC end address is ambiguous; see the SYS-SUP-018 finding. |
| F-sys-req-set-r12-001 | set | 12 | SYS-SUP-016 | IQ-03 | blocking | resolved | CON-SUP-107, CON-SUP-124 and CON-SUP-129 do not establish whether the byte at __app_end is included in the CRC input. SYS-SUP-016 therefore admits different CRC inputs. |
| F-sys-req-set-r12-002 | set | 12 | SYS-SUP-018 | IQ-03 | blocking | resolved | CON-SUP-142 does not establish whether the byte at __cfg_end is included in the configuration CRC input. SYS-SUP-018 therefore admits different CRC inputs. |
| F-sys-req-set-r12-003 | set | 12 | SET | SQ-01 | major | resolved | Coverage of CON-SUP-142 is partial because the configuration CRC endpoint is ambiguous. OP-SYS-005 records the missing product decision. |
| F-sys-req-item-r11-001 | item | 11 | SYS-SUP-005 | IQ-05 | major | resolved | The requirement combines treatment of a start delay equal to its limit with treatment of an execution time equal to its limit. Either behavior could pass while the other fails. |
| F-sys-req-item-r11-002 | item | 11 | SYS-SUP-056 | IQ-05 | major | resolved | The requirement combines detection of a start-delay violation with detection of an execution-time violation. Either detection can meet the deadline while the other fails. |
| F-sys-req-item-r12-001 | item | 12 | SYS-SUP-005 | IQ-06 | blocking | resolved | The requirement specifies the result at exactly the start limit, but its cited verification constraint CON-SUP-127 calls for test margins of at least 200 µs on either side of the limit. A test using those margins does not establish the behavior at equality. |
| F-sys-req-item-r12-002 | item | 12 | SYS-SUP-092 | IQ-06 | blocking | resolved | The requirement specifies the result at exactly the execution limit, but its cited verification constraint CON-SUP-127 calls for test margins of at least 200 µs on either side of the limit. A test using those margins does not establish the behavior at equality. |
| F-sys-req-item-r13-001 | item | 13 | SYS-SUP-005 | IQ-06 | blocking | resolved | The requirement specifies behavior at exact equality and names test as its verification method, but CON-SUP-127 requires verification margins of at least 200 µs on either side of the limit. A test using those margins cannot establish the equality behavior. |
| F-sys-req-item-r13-002 | item | 13 | SYS-SUP-092 | IQ-06 | blocking | resolved | The requirement specifies behavior at exact equality and names test as its verification method, but CON-SUP-127 requires verification margins of at least 200 µs on either side of the limit. A test using those margins cannot establish the equality behavior. |
| F-sys-req-set-r13-001 | set | 13 | SYS-SUP-005 | IQ-06 | blocking | resolved | The requirement specifies behavior at exact equality and names test as its verification method, but CON-SUP-127 requires verification margins of at least 200 µs on either side of the limit. Those margin tests cannot establish the equality behavior. |
| F-sys-req-set-r13-002 | set | 13 | SYS-SUP-092 | IQ-06 | blocking | resolved | The requirement specifies behavior at exact equality and names test as its verification method, but CON-SUP-127 requires verification margins of at least 200 µs on either side of the limit. Those margin tests cannot establish the equality behavior. |
| F-sys-req-set-r14-001 | set | 14 | SYS-SUP-002 | SQ-10 | major | resolved | SYS-SUP-002 states that a start delay equal to the limit is within the limit but names test as its verification method. CON-SUP-147 requires a requirement stating the equality rule to name analysis; the specified margin tests do not verify equality. |
| F-sys-req-set-r14-002 | set | 14 | SYS-SUP-003 | SQ-10 | major | resolved | SYS-SUP-003 states that an execution time equal to the limit is within the limit but names test as its verification method. CON-SUP-147 requires a requirement stating the equality rule to name analysis; the specified margin tests do not verify equality. |
| F-sys-req-set-r15-001 | set | 15 | SET | SQ-10 | major | resolved | CON-SUP-127 and CON-SUP-147 require timing-limit tests to use margins of at least 200 µs on either side of a limit. The set records test methods for SYS-SUP-002, SYS-SUP-003, SYS-SUP-056 and SYS-SUP-093 but does not record that verification constraint. |
| F-sys-req-set-r15-002 | set | 15 | SYS-SUP-054 | SQ-05 | blocking | resolved | SYS-SUP-054 says every system requirement can be verified on the simulator or by host unit tests, while SYS-SUP-072 requires inspection of board pull-down resistors and SYS-SUP-086 specifies analysis of the board output-stage timing. Those verification approaches are not established as simulator or host unit tests. |

### Coverage matrix (set inspection round 16)

| Source | Requirements | Status | Reason | Tracked by |
|---|---|---|---|---|
| STK-SUP-001 | SYS-SUP-001, SYS-SUP-009 | covered |  |  |
| STK-SUP-002 | SYS-SUP-002, SYS-SUP-003, SYS-SUP-005, SYS-SUP-092, SYS-SUP-056, SYS-SUP-093 | covered |  |  |
| STK-SUP-003 | SYS-SUP-004, SYS-SUP-041 | covered |  |  |
| STK-SUP-004 | SYS-SUP-006, SYS-SUP-007, SYS-SUP-076, SYS-SUP-077, SYS-SUP-078, SYS-SUP-079, SYS-SUP-080 | covered |  |  |
| STK-SUP-005 | SYS-SUP-010, SYS-SUP-013, SYS-SUP-014 | covered |  |  |
| STK-SUP-006 | SYS-SUP-011, SYS-SUP-012 | covered |  |  |
| STK-SUP-007 | SYS-SUP-016, SYS-SUP-017, SYS-SUP-018, SYS-SUP-019, SYS-SUP-020 | covered |  |  |
| STK-SUP-008 | SYS-SUP-021, SYS-SUP-022, SYS-SUP-023, SYS-SUP-058, SYS-SUP-066 | covered |  |  |
| STK-SUP-009 | SYS-SUP-024, SYS-SUP-025, SYS-SUP-026, SYS-SUP-027, SYS-SUP-072, SYS-SUP-086 | covered |  |  |
| STK-SUP-010 | SYS-SUP-029, SYS-SUP-030, SYS-SUP-031, SYS-SUP-032, SYS-SUP-033, SYS-SUP-059, SYS-SUP-060, SYS-SUP-064, SYS-SUP-065, SYS-SUP-070, SYS-SUP-071 | covered |  |  |
| STK-SUP-011 | SYS-SUP-036, SYS-SUP-037, SYS-SUP-038 | covered |  |  |
| STK-SUP-012 | SYS-SUP-034, SYS-SUP-039, SYS-SUP-040, SYS-SUP-041, SYS-SUP-042 | covered |  |  |
| STK-SUP-013 | SYS-SUP-045, SYS-SUP-046, SYS-SUP-047, SYS-SUP-048, SYS-SUP-063, SYS-SUP-067, SYS-SUP-068, SYS-SUP-069, SYS-SUP-081 | covered |  |  |
| STK-SUP-014 | SYS-SUP-052 | covered |  |  |
| STK-SUP-015 | SYS-SUP-053, SYS-SUP-054, SYS-SUP-055 | covered |  |  |
| CON-SUP-001 | SYS-SUP-083 | covered |  |  |
| CON-SUP-002 | - | n/a | Identifies a reference manual and citation restrictions; it does not impose a separate product behavior. |  |
| CON-SUP-003 | SYS-SUP-011, SYS-SUP-012, SYS-SUP-036, SYS-SUP-044 | covered | Identifies available peripherals; applicable functional uses are addressed by the requirements. |  |
| CON-SUP-004 | SYS-SUP-084, SYS-SUP-087, SYS-SUP-088 | covered |  |  |
| CON-SUP-005 | SYS-SUP-054 | covered |  |  |
| CON-SUP-006 | SYS-SUP-006, SYS-SUP-076, SYS-SUP-077 | covered |  |  |
| CON-SUP-007 | SYS-SUP-044 | covered |  |  |
| CON-SUP-101 | SYS-SUP-006, SYS-SUP-076, SYS-SUP-077 | covered |  |  |
| CON-SUP-102 | SYS-SUP-001, SYS-SUP-009 | covered |  |  |
| CON-SUP-103 | SYS-SUP-002, SYS-SUP-003, SYS-SUP-078, SYS-SUP-079, SYS-SUP-080, SYS-SUP-085, SYS-SUP-091 | covered |  |  |
| CON-SUP-104 | SYS-SUP-004 | covered |  |  |
| CON-SUP-105 | SYS-SUP-024, SYS-SUP-025 | covered |  |  |
| CON-SUP-106 | SYS-SUP-011, SYS-SUP-012, SYS-SUP-013, SYS-SUP-014 | covered |  |  |
| CON-SUP-107 | SYS-SUP-016, SYS-SUP-018, SYS-SUP-020, SYS-SUP-089 | covered |  |  |
| CON-SUP-108 | SYS-SUP-021, SYS-SUP-022, SYS-SUP-058, SYS-SUP-066 | covered |  |  |
| CON-SUP-109 | SYS-SUP-024, SYS-SUP-026, SYS-SUP-028 | covered |  |  |
| CON-SUP-110 | SYS-SUP-029, SYS-SUP-030, SYS-SUP-033, SYS-SUP-059, SYS-SUP-060 | covered | Read with the later product-owner clarifications. |  |
| CON-SUP-111 | SYS-SUP-036, SYS-SUP-037, SYS-SUP-038 | covered |  |  |
| CON-SUP-112 | SYS-SUP-034, SYS-SUP-039, SYS-SUP-040, SYS-SUP-041 | covered | Read with the later product-owner clarifications. |  |
| CON-SUP-113 | SYS-SUP-045, SYS-SUP-048, SYS-SUP-049, SYS-SUP-081 | covered |  |  |
| CON-SUP-114 | SYS-SUP-052 | covered |  |  |
| CON-SUP-115 | SYS-SUP-008, SYS-SUP-057 | covered |  |  |
| CON-SUP-116 | SYS-SUP-053, SYS-SUP-054, SYS-SUP-055 | covered |  |  |
| CON-SUP-117 | SYS-SUP-029, SYS-SUP-030, SYS-SUP-059, SYS-SUP-060, SYS-SUP-064, SYS-SUP-065, SYS-SUP-070, SYS-SUP-071 | covered | Read with the later per-code counting clarification. |  |
| CON-SUP-118 | SYS-SUP-038 | covered |  |  |
| CON-SUP-119 | SYS-SUP-008, SYS-SUP-034, SYS-SUP-040 | covered |  |  |
| CON-SUP-120 | SYS-SUP-024, SYS-SUP-029, SYS-SUP-039 | covered |  |  |
| CON-SUP-121 | SYS-SUP-010, SYS-SUP-026, SYS-SUP-029, SYS-SUP-034, SYS-SUP-039 | covered |  |  |
| CON-SUP-122 | SYS-SUP-041 | covered |  |  |
| CON-SUP-123 | SYS-SUP-041 | covered |  |  |
| CON-SUP-124 | SYS-SUP-016 | covered |  |  |
| CON-SUP-125 | SYS-SUP-046, SYS-SUP-047, SYS-SUP-067, SYS-SUP-068, SYS-SUP-069 | covered |  |  |
| CON-SUP-126 | SYS-SUP-042 | covered |  |  |
| CON-SUP-127 | SYS-SUP-002, SYS-SUP-003, SYS-SUP-005, SYS-SUP-056, SYS-SUP-092, SYS-SUP-093 | covered | The test margins are recorded in the timing requirements; equality is assigned to analysis. |  |
| CON-SUP-128 | SYS-SUP-002 | covered |  |  |
| CON-SUP-129 | SYS-SUP-016, SYS-SUP-018, SYS-SUP-066 | covered |  |  |
| CON-SUP-130 | SYS-SUP-035, SYS-SUP-046, SYS-SUP-061, SYS-SUP-062, SYS-SUP-065, SYS-SUP-067, SYS-SUP-068, SYS-SUP-069 | covered |  |  |
| CON-SUP-131 | SYS-SUP-042 | covered |  |  |
| CON-SUP-132 | SYS-SUP-026, SYS-SUP-027, SYS-SUP-072, SYS-SUP-073 | covered |  |  |
| CON-SUP-133 | SYS-SUP-025, SYS-SUP-086 | covered |  |  |
| CON-SUP-134 | SYS-SUP-081 | covered |  |  |
| CON-SUP-135 | SYS-SUP-032, SYS-SUP-059 | covered |  |  |
| CON-SUP-136 | SYS-SUP-032, SYS-SUP-059 | covered |  |  |
| CON-SUP-137 | SYS-SUP-015, SYS-SUP-035, SYS-SUP-061, SYS-SUP-062 | covered | The start-up servicing mechanism is deferred by OP-SYS-002; the observable outcome is specified. |  |
| CON-SUP-138 | SYS-SUP-049, SYS-SUP-051, SYS-SUP-063 | covered |  |  |
| CON-SUP-139 | SYS-SUP-043, SYS-SUP-050, SYS-SUP-063, SYS-SUP-074 | covered |  |  |
| CON-SUP-140 | SYS-SUP-030, SYS-SUP-031, SYS-SUP-059, SYS-SUP-065 | covered |  |  |
| CON-SUP-141 | SYS-SUP-042 | covered |  |  |
| CON-SUP-142 | SYS-SUP-018 | covered |  |  |
| CON-SUP-143 | SYS-SUP-074, SYS-SUP-075 | covered |  |  |
| CON-SUP-144 | SYS-SUP-034 | covered |  |  |
| CON-SUP-145 | SYS-SUP-037, SYS-SUP-090 | covered |  |  |
| CON-SUP-146 | SYS-SUP-016, SYS-SUP-018, SYS-SUP-066, SYS-SUP-089 | covered |  |  |
| CON-SUP-147 | SYS-SUP-002, SYS-SUP-003, SYS-SUP-005, SYS-SUP-056, SYS-SUP-092, SYS-SUP-093 | covered | The equality requirements name analysis; the timing tests record the required margins. |  |
| UC-SUP-001 | SYS-SUP-001, SYS-SUP-002, SYS-SUP-003, SYS-SUP-004 | covered |  |  |
| UC-SUP-002 | SYS-SUP-006, SYS-SUP-007, SYS-SUP-076, SYS-SUP-077, SYS-SUP-078, SYS-SUP-079, SYS-SUP-080 | covered |  |  |
| UC-SUP-003 | SYS-SUP-010, SYS-SUP-011, SYS-SUP-012, SYS-SUP-013, SYS-SUP-014 | covered |  |  |
| UC-SUP-004 | SYS-SUP-016, SYS-SUP-017, SYS-SUP-018, SYS-SUP-019, SYS-SUP-020 | covered |  |  |
| UC-SUP-005 | SYS-SUP-021, SYS-SUP-022, SYS-SUP-023, SYS-SUP-058, SYS-SUP-066 | covered |  |  |
| UC-SUP-006 | SYS-SUP-024, SYS-SUP-025, SYS-SUP-026, SYS-SUP-072, SYS-SUP-086 | covered |  |  |
| UC-SUP-007 | SYS-SUP-029, SYS-SUP-030, SYS-SUP-059, SYS-SUP-060, SYS-SUP-064, SYS-SUP-065, SYS-SUP-070, SYS-SUP-071 | covered |  |  |
| UC-SUP-008 | SYS-SUP-036, SYS-SUP-037, SYS-SUP-038 | covered |  |  |
| UC-SUP-009 | SYS-SUP-034, SYS-SUP-039, SYS-SUP-040, SYS-SUP-041, SYS-SUP-042 | covered |  |  |
| UC-SUP-010 | SYS-SUP-045, SYS-SUP-046, SYS-SUP-047, SYS-SUP-048, SYS-SUP-063, SYS-SUP-081 | covered |  |  |
| UC-SUP-011 | SYS-SUP-052 | covered |  |  |
| UC-SUP-012 | SYS-SUP-053, SYS-SUP-054, SYS-SUP-055 | covered |  |  |
| start-up | SYS-SUP-015, SYS-SUP-016, SYS-SUP-018, SYS-SUP-020, SYS-SUP-026, SYS-SUP-027, SYS-SUP-036 | covered |  |  |
| normal operation | SYS-SUP-001, SYS-SUP-002, SYS-SUP-003, SYS-SUP-004, SYS-SUP-013, SYS-SUP-014, SYS-SUP-021, SYS-SUP-067 | covered |  |  |
| invalid input | SYS-SUP-008, SYS-SUP-049, SYS-SUP-057 | covered |  |  |
| fault detection and reaction | SYS-SUP-001, SYS-SUP-002, SYS-SUP-003, SYS-SUP-004, SYS-SUP-017, SYS-SUP-019, SYS-SUP-023, SYS-SUP-024, SYS-SUP-039 | covered |  |  |
| recovery or reset | SYS-SUP-029, SYS-SUP-030, SYS-SUP-033, SYS-SUP-034, SYS-SUP-036, SYS-SUP-059, SYS-SUP-060, SYS-SUP-070 | covered |  |  |
| shutdown | - | n/a | The inputs specify reset and a power-cycle-cleared safe-state latch, but no commanded shutdown mode or shutdown sequence. |  |
| non-functional limits | SYS-SUP-022, SYS-SUP-024, SYS-SUP-025, SYS-SUP-052, SYS-SUP-058, SYS-SUP-063, SYS-SUP-086, SYS-SUP-089 | covered |  |  |

## sw-req: Software requirements

| Id | Phase | Round | Item | Checklist | Severity | Status | Description |
|---|---|---|---|---|---|---|---|
| F-sw-req-item-r1-001 | item | 1 | SWR-WDG-006 | IQ-04 | major | resolved | The requirement bounds only the interval between consecutive services while integrity checks run. It does not bound the interval from watchdog activation to the first service or from the last service to the end of start-up; it can also be satisfied without two services. SYS-SUP-015 requires prevention of an independent watchdog reset throughout fault-free start-up. |
| F-sw-req-item-r1-002 | item | 1 | SWR-WDG-007 | IQ-04 | major | resolved | The requirement constrains each window-watchdog refresh but does not require a refresh before the window expires. An implementation making no refresh satisfies the statement even if an enabled watchdog resets during fault-free start-up, contrary to SYS-SUP-015. |
| F-sw-req-item-r1-003 | item | 1 | SWR-SAF-002 | IQ-10 | major | resolved | The requirement assigns the supervisor software responsibility for holding the outputs low from any reset, including the interval before software configures the pins. CON-SUP-132 assigns the low level during that interval to external pull-down resistors, while the pins are inputs. |
| F-sw-req-item-r1-004 | item | 1 | SWR-DIA-002 | IQ-05 | major | resolved | The requirement combines independently verifiable mappings for nine fault codes and multiple entity values. A report can use the correct mapping for one fault class and an incorrect mapping for another. |
| F-sw-req-item-r1-005 | item | 1 | SWR-LAT-007 | IQ-05 | major | resolved | Retention of the safe-state latch, per-code detection counts and fault history are independently verifiable obligations: any one can be retained across resets while another is lost. |
| F-sw-req-item-r2-001 | item | 2 | SWR-WDG-007 | IQ-09 | blocking | resolved | The requirement places no lower bound on the first refresh after the window watchdog is enabled, so it permits an early refresh that causes a reset during fault-free start-up, contrary to SYS-SUP-015. OP-SWR-001 also identifies this missing first-refresh limit. |
| F-sw-req-item-r2-002 | item | 2 | SWR-WDG-007 | IQ-04 | major | resolved | The requirement bounds refresh intervals during start-up but does not bound the interval between the last start-up refresh and the first refresh under SWR-WDG-004. That first normal refresh could occur too early or too late and cause a watchdog reset. |
| F-sw-req-item-r3-001 | item | 3 | SWR-WDG-007 | IQ-04 | major | resolved | The requirement bounds the interval from enabling to the first refresh and from the last refresh to the end of start-up, but does not define those intervals when start-up ends before any refresh. OP-SWR-001 permits enabling only at the first control cycle, so a start-up with no refresh is a relevant case. |
| F-sw-req-item-r3-002 | item | 3 | SWR-WDG-008 | IQ-09 | blocking | resolved | A fault-free start-up followed by a fault before the first refresh under SWR-WDG-004 satisfies this requirement's condition, yet SWR-WDG-001 and SYS-SUP-010 prohibit servicing after detection. The required first refresh therefore conflicts with the stop-servicing obligation. |
| F-sw-req-item-r4-001 | item | 4 | SWR-WDG-007 | IQ-09 | blocking | resolved | For a fault-free start-up with no start-up refresh, the requirement bounds the time to the first refresh under SWR-WDG-004 even if a fault is detected after start-up and before that refresh. SWR-WDG-001 prohibits watchdog servicing from fault detection until reset. |
| F-sw-req-item-r4-002 | item | 4 | SWR-WDG-007 | IQ-05 | major | resolved | The requirement combines independently judgeable bounds for consecutive refreshes, the first refresh after enabling, the end of start-up, and the no-refresh transition. One bound can fail while the others pass. |
| F-sw-req-set-r1-001 | set | 1 | SWR-WDG-007 | IQ-09 | blocking | resolved | After a fault-free start-up with no window-watchdog refresh, the requirement bounds the first refresh under SWR-WDG-004 even if a fault is detected before that refresh. SWR-WDG-001 prohibits servicing from fault detection until reset. |
| F-sw-req-set-r1-002 | set | 1 | SWR-WDG-007 | IQ-05 | major | resolved | The requirement combines independently verifiable bounds for consecutive refreshes, the first refresh after enabling, the end of start-up, and the transition when no refresh occurs during start-up. |
| F-sw-req-set-r1-003 | set | 1 | SET | SQ-01 | major | resolved | SYS-SUP-054 requires the test or demonstration verification of every system requirement on the simulator or host tests. SWR-TST-002 limits this provision to software requirements, leaving the system-level verification scope unaddressed. |

### Coverage matrix (set inspection round 2)

| Source | Requirements | Status | Reason | Tracked by |
|---|---|---|---|---|
| SYS-SUP-001 | SWR-ALV-001 | covered |  |  |
| SYS-SUP-002 | SWR-TIM-001 | covered |  |  |
| SYS-SUP-003 | SWR-TIM-002 | covered |  |  |
| SYS-SUP-004 | SWR-FLW-001 | covered |  |  |
| SYS-SUP-005 | SWR-TIM-003 | covered |  |  |
| SYS-SUP-006 | SWR-CFG-001 | covered |  |  |
| SYS-SUP-007 | SWR-CFG-007 | covered |  |  |
| SYS-SUP-008 | SWR-CFG-008 | covered |  |  |
| SYS-SUP-009 | SWR-ALV-002 | covered |  |  |
| SYS-SUP-010 | SWR-WDG-001 | covered |  |  |
| SYS-SUP-011 | SWR-WDG-002 | covered |  |  |
| SYS-SUP-012 | SWR-WDG-003, SWR-WDG-007, SWR-WDG-008, SWR-WDG-009, SWR-WDG-010, SWR-WDG-011, SWR-WDG-012 | covered |  |  |
| SYS-SUP-013 | SWR-WDG-004, SWR-WDG-008, SWR-WDG-011, SWR-WDG-012 | covered |  |  |
| SYS-SUP-014 | SWR-WDG-005 | covered |  |  |
| SYS-SUP-015 | SWR-WDG-006, SWR-WDG-007, SWR-WDG-008, SWR-WDG-009, SWR-WDG-010, SWR-WDG-011, SWR-WDG-012 | covered |  |  |
| SYS-SUP-016 | SWR-CHK-001 | covered |  |  |
| SYS-SUP-017 | SWR-CHK-002 | covered |  |  |
| SYS-SUP-018 | SWR-CHK-003 | covered |  |  |
| SYS-SUP-019 | SWR-CHK-004 | covered |  |  |
| SYS-SUP-020 | SWR-CHK-005 | covered |  |  |
| SYS-SUP-021 | SWR-CHK-006 | covered |  |  |
| SYS-SUP-022 | SWR-CHK-008 | covered |  |  |
| SYS-SUP-023 | SWR-CHK-009 | covered |  |  |
| SYS-SUP-024 | SWR-SAF-001 | covered | The software pin deadline supports the allocated software share; the output-stage delay is allocated to hardware. |  |
| SYS-SUP-025 | SWR-SAF-001 | covered |  |  |
| SYS-SUP-026 | SWR-SAF-002, SWR-SAF-003, SWR-SAF-007 | covered | The software share begins when the pins are configured; the preceding low level is supplied by the hardware pull-downs. |  |
| SYS-SUP-027 | SWR-SAF-003 | covered |  |  |
| SYS-SUP-028 | SWR-SAF-004 | covered |  |  |
| SYS-SUP-029 | SWR-LAT-001 | covered |  |  |
| SYS-SUP-030 | SWR-LAT-002 | covered |  |  |
| SYS-SUP-031 | SWR-LAT-005 | covered |  |  |
| SYS-SUP-032 | SWR-LAT-006 | covered |  |  |
| SYS-SUP-033 | SWR-LAT-007, SWR-LAT-013, SWR-LAT-014 | covered |  |  |
| SYS-SUP-034 | SWR-RST-003 | covered |  |  |
| SYS-SUP-035 | SWR-LAT-012 | covered |  |  |
| SYS-SUP-036 | SWR-RST-001 | covered |  |  |
| SYS-SUP-037 | SWR-RST-002 | covered |  |  |
| SYS-SUP-038 | SWR-SVC-001 | covered |  |  |
| SYS-SUP-039 | SWR-DIA-001 | covered |  |  |
| SYS-SUP-040 | SWR-DIA-002, SWR-DIA-008, SWR-DIA-009, SWR-DIA-010, SWR-DIA-011, SWR-DIA-012, SWR-DIA-013, SWR-DIA-014, SWR-DIA-015 | covered |  |  |
| SYS-SUP-041 | SWR-FLW-002 | covered |  |  |
| SYS-SUP-042 | SWR-DIA-003 | covered |  |  |
| SYS-SUP-043 | SWR-DIA-004 | covered |  |  |
| SYS-SUP-044 | SWR-DIA-007 | covered |  |  |
| SYS-SUP-045 | SWR-SVC-002 | covered |  |  |
| SYS-SUP-046 | SWR-SVC-003 | covered |  |  |
| SYS-SUP-047 | SWR-SVC-007 | covered |  |  |
| SYS-SUP-048 | SWR-SVC-008, SWR-SVC-014 | covered |  |  |
| SYS-SUP-049 | SWR-SVC-011 | covered |  |  |
| SYS-SUP-050 | SWR-SVC-012 | covered |  |  |
| SYS-SUP-051 | SWR-SVC-013 | covered |  |  |
| SYS-SUP-052 | SWR-RES-001 | covered |  |  |
| SYS-SUP-053 | SWR-TST-001 | covered |  |  |
| SYS-SUP-054 | SWR-TST-002 | covered | SWR-TST-002 covers all system requirements allocated to software with test or demonstration methods. The two hardware-only requirements in the current system set use inspection and analysis. |  |
| SYS-SUP-055 | SWR-TST-003 | covered |  |  |
| SYS-SUP-056 | SWR-TIM-001 | covered |  |  |
| SYS-SUP-057 | SWR-CFG-009 | covered |  |  |
| SYS-SUP-058 | SWR-CHK-011 | covered |  |  |
| SYS-SUP-059 | SWR-LAT-008 | covered |  |  |
| SYS-SUP-060 | SWR-LAT-009 | covered |  |  |
| SYS-SUP-061 | SWR-LAT-010 | covered |  |  |
| SYS-SUP-062 | SWR-LAT-011 | covered |  |  |
| SYS-SUP-063 | SWR-SVC-014 | covered |  |  |
| SYS-SUP-064 | SWR-LAT-003 | covered |  |  |
| SYS-SUP-065 | SWR-LAT-004 | covered |  |  |
| SYS-SUP-066 | SWR-CHK-007 | covered |  |  |
| SYS-SUP-067 | SWR-SVC-004 | covered |  |  |
| SYS-SUP-068 | SWR-SVC-005 | covered |  |  |
| SYS-SUP-069 | SWR-SVC-006 | covered |  |  |
| SYS-SUP-070 | SWR-SAF-005 | covered |  |  |
| SYS-SUP-071 | SWR-SAF-006 | covered |  |  |
| SYS-SUP-073 | SWR-SAF-007 | covered |  |  |
| SYS-SUP-074 | SWR-DIA-005 | covered |  |  |
| SYS-SUP-075 | SWR-DIA-006 | covered |  |  |
| SYS-SUP-076 | SWR-CFG-002 | covered |  |  |
| SYS-SUP-077 | SWR-CFG-003 | covered |  |  |
| SYS-SUP-078 | SWR-CFG-004 | covered |  |  |
| SYS-SUP-079 | SWR-CFG-005 | covered |  |  |
| SYS-SUP-080 | SWR-CFG-006 | covered |  |  |
| SYS-SUP-081 | SWR-SVC-009 | covered |  |  |
| SYS-SUP-082 | SWR-SVC-010 | covered |  |  |
| SYS-SUP-083 | SWR-PLT-001 | covered |  |  |
| SYS-SUP-084 | SWR-PLT-002 | covered |  |  |
| SYS-SUP-085 | SWR-TIM-005 | covered |  |  |
| SYS-SUP-087 | SWR-PLT-003 | covered |  |  |
| SYS-SUP-088 | SWR-PLT-004 | covered |  |  |
| SYS-SUP-089 | SWR-CHK-010 | covered |  |  |
| SYS-SUP-090 | SWR-RST-004 | covered |  |  |
| SYS-SUP-091 | SWR-TIM-006 | covered |  |  |
| SYS-SUP-092 | SWR-TIM-004 | covered |  |  |
| SYS-SUP-093 | SWR-TIM-002 | covered |  |  |
| start-up | SWR-CHK-001, SWR-CHK-003, SWR-CHK-005, SWR-SAF-002, SWR-SAF-003, SWR-WDG-006, SWR-WDG-007, SWR-WDG-009, SWR-WDG-010, SWR-WDG-011, SWR-WDG-012 | covered |  |  |
| normal operation | SWR-ALV-001, SWR-TIM-001, SWR-TIM-002, SWR-FLW-001, SWR-CHK-006, SWR-CHK-007, SWR-WDG-004, SWR-WDG-005 | covered |  |  |
| invalid input | SWR-CFG-008, SWR-SVC-011, SWR-SVC-012 | covered |  |  |
| fault detection and reaction | SWR-ALV-001, SWR-TIM-001, SWR-TIM-002, SWR-FLW-001, SWR-CHK-002, SWR-CHK-004, SWR-CHK-009, SWR-CFG-008, SWR-WDG-001, SWR-SAF-001, SWR-DIA-001 | covered |  |  |
| recovery and reset | SWR-LAT-001, SWR-LAT-002, SWR-LAT-003, SWR-LAT-004, SWR-LAT-008, SWR-LAT-009, SWR-RST-001, SWR-RST-002, SWR-RST-003 | covered |  |  |
| shutdown | - | n/a | The supplied inputs specify reset and a latched safe state, but no separate software shutdown mode. |  |
| limits | SWR-TIM-005, SWR-TIM-006, SWR-WDG-002, SWR-WDG-003, SWR-CHK-008, SWR-CHK-010, SWR-CHK-011, SWR-SAF-001, SWR-RES-001 | covered |  |  |

