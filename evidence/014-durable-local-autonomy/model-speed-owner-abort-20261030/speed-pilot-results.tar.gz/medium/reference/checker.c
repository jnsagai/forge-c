#include <stdint.h>
#include <stdio.h>
uint32_t reg_enable(uint32_t before);
int main(void) {
    const uint32_t edge[] = {UINT32_C(0x80000000), UINT32_C(0xffffffff), UINT32_C(0xfffffffe), UINT32_C(0x7fffffff)};
    unsigned int failures = 0, checked = 0;
    uint32_t first_in = 0, first_out = 0, first_expected = 0;
    for (unsigned int i = 0; i < 260; ++i) {
        uint32_t input = i < 256 ? (uint32_t)i : edge[i - 256];
        uint32_t output = reg_enable(input), expected = input | UINT32_C(1);
        ++checked;
        if (output != expected || reg_enable(output) != output) {
            if (failures == 0) { first_in = input; first_out = output; first_expected = expected; }
            ++failures;
        }
    }
    printf("{\"checked\":%u,\"failures\":%u,\"input\":%u,\"observed\":%u,\"expected\":%u}\n",
           checked, failures, (unsigned int)first_in, (unsigned int)first_out, (unsigned int)first_expected);
    return failures == 0 ? 0 : 1;
}
