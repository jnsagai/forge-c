#include <stdint.h>
uint32_t reg_enable(uint32_t before) { return before | UINT32_C(1); }
