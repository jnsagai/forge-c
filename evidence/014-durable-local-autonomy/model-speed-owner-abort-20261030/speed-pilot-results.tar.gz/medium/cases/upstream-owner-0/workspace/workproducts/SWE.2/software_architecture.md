SWU-REG32 implements SWR-001 using EN mask 2.
