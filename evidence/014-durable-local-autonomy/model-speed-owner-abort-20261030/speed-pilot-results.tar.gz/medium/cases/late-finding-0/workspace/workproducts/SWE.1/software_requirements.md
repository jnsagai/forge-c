# Seeded REG32 qualification fixture (not an STM32 product)
SWR-001 / USPEC-001: reg_enable(before) shall return the 32-bit register value
with EN (bit 0, mask UINT32_C(1)) set and every other bit unchanged.
The operation shall be idempotent. Inputs include zero and full-width boundaries.
This is a frozen protocol test, not a production failure or a promoted remedy.
