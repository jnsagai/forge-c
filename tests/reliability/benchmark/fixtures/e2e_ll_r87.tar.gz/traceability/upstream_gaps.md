# Upstream coverage

## (a) Upstream input coverage

| Upstream input | Status as stated in the manifest | Affected SWR IDs |
| --- | --- | --- |
| HSI contract (RM0486 Rev 4 ch.14 RCC register interface + memory map p.176) | Target decision recorded: `target.hsi_contract` ("owner decision 2026-10-15"); no separate `inputs/upstream-inputs.yaml` was provided (`upstream.status = NOT_PROVIDED`) | SWR-001 .. SWR-024 |
| Safety allocation | `target.safety_allocation = "OUT_OF_SCOPE: QM development, no safety allocation or safety claims (owner decision 2026-10-15)"` | none (no SWR allocated to safety; see safety/software_safety_requirements.md) |
| Budgets | `budgets.status = "development targets set by the work-order owner (2026-10-15)"`: flash_bytes 4096, static_ram_bytes 64, stack_bytes 128 | SWR-025, SWR-026, SWR-027 |
| MCU profile / part | `target.part_number = STM32N657X0 (STM32N6x5/x7 family)`, `target.core = Arm Cortex-M55`, `target.silicon_revision = UNSPECIFIED` | SWR-001 .. SWR-024 |

## (b) Bidirectional traceability

| Upstream id | SWR IDs |
| --- | --- |
| RM0486-14.10.1 | SWR-001, SWR-002, SWR-003, SWR-004, SWR-021, SWR-024 |
| RM0486-14.10.2 | SWR-005, SWR-006, SWR-007, SWR-008 |
| RM0486-14.10.79 | SWR-009, SWR-010, SWR-011, SWR-012, SWR-013, SWR-014, SWR-015, SWR-016, SWR-022 |
| RM0486-14.10.64 | SWR-017, SWR-018, SWR-019, SWR-020, SWR-023 |
| WO-BUDGET | SWR-025, SWR-026, SWR-027 |

| SWR ID | Upstream id |
| --- | --- |
| SWR-001 | RM0486-14.10.1 |
| SWR-002 | RM0486-14.10.1 |
| SWR-003 | RM0486-14.10.1 |
| SWR-004 | RM0486-14.10.1 |
| SWR-005 | RM0486-14.10.2 |
| SWR-006 | RM0486-14.10.2 |
| SWR-007 | RM0486-14.10.2 |
| SWR-008 | RM0486-14.10.2 |
| SWR-009 | RM0486-14.10.79 |
| SWR-010 | RM0486-14.10.79 |
| SWR-011 | RM0486-14.10.79 |
| SWR-012 | RM0486-14.10.79 |
| SWR-013 | RM0486-14.10.79 |
| SWR-014 | RM0486-14.10.79 |
| SWR-015 | RM0486-14.10.79 |
| SWR-016 | RM0486-14.10.79 |
| SWR-017 | RM0486-14.10.64 |
| SWR-018 | RM0486-14.10.64 |
| SWR-019 | RM0486-14.10.64 |
| SWR-020 | RM0486-14.10.64 |
| SWR-021 | RM0486-14.10.1 |
| SWR-022 | RM0486-14.10.79 |
| SWR-023 | RM0486-14.10.64 |
| SWR-024 | RM0486-14.10.1 |
| SWR-025 | WO-BUDGET |
| SWR-026 | WO-BUDGET |
| SWR-027 | WO-BUDGET |

## Notes

- No upstream software safety requirement exists, so no SWR carries an SSR id; the safety allocation is
  OUT_OF_SCOPE (QM) and nothing has been invented.
- `inputs/upstream-inputs.yaml` is not present in this work order (manifest `upstream.status = NOT_PROVIDED`,
  upstream issues list DRAFT_TEMPLATE/PLACEHOLDER entries); the HSI contract and budgets are taken from the
  approved manifest as recorded by the work-order owner.
