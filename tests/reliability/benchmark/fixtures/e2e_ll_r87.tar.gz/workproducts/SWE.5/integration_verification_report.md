# SWE.5 Integration verification report

Scope: STM32N6 RCC low-level (LL) driver, header-only (`software/ll/stm32n6xx_ll_rcc.h`), built from the frozen
SWE.2 baseline BL-SWE.2-001 and the SWE.3/SWE.4 baselines. This report covers component and integration
verification of the LL, plus the target (Renode) execution of the target tests authored in the SWE.5 target step.

## Plan

Component and integration measures performed:

| Measure | Level | Artefact | Requirement coverage |
|---|---|---|---|
| Component (unit) verification of every LL function | unit | `software/tests/unit/test_rcc.c` (SWE.4 baseline), 24 checks | SWR-001..SWR-027 |
| Integration verification of LL sequences a HAL will use | integration | `software/tests/integration/test_rcc_integration.c`, 13 checks | SWR-001..SWR-023, SWR-024 |
| Target execution of the driver on the simulated Cortex-M55 | target (Renode) | `software/tests/target/test_rcc_target.c`, `software/tests/target/test_rcc_target_timeout.c` | SWR-001..SWR-023 |
| Size verification against the work-order budgets | build | `forge-build-mcp.measure_elf` / `stack_usage` | SWR-025, SWR-026, SWR-027 |

Integration is exercised through the caller-visible interface only: the LL has no parameters, no state and no
initialization, so every integration measure is a sequence of LL calls interleaved with caller-side
observations of the RCC register words in `ll_rcc_regs[]` (SWE.2 section 2). No internal symbol, no test-only
hook and no driver modification is used.

## Integration sequence

The sequences match the interfaces of `workproducts/SWE.2/software_architecture.md` section 3:

1. `LL_RCC_HSI_Enable` / `LL_RCC_HSE_Enable` (no parameters, `void`) followed by a caller-owned bounded loop
   on `LL_RCC_HSI_IsReady` / `LL_RCC_HSE_IsReady` (`uint32_t`, exactly 1U or 0U), sequence of SWE.2 section 4
   ("the caller bounds its own polling loop on `LL_RCC_HSI_IsReady` / `LL_RCC_HSE_IsReady` and applies its own
   timeout").
2. `LL_RCC_<peripheral>_Enable` / `_Disable` / `_IsEnabled` for the peripherals of the register table
   (GPDMA1, ADC12 in RCC_AHB1ENR), sequence of SWE.2 section 3.2.
3. `LL_RCC_<peripheral>_ForceReset` / `_ReleaseReset` (RCC_AHB1RSTR), sequence of SWE.2 section 3.3, run both
   standalone and as the HAL-like order clock-enable -> reset-assert -> reset-release.
4. Cross-group interleaving of oscillator, clock-enable and reset calls to check the register-preservation
   contract of SWE.2 section 2 ("preserves every other bit of the register", SWR-021..SWR-023).

The static dependency of the architecture (`Caller -> stm32n6xx_ll_rcc -> RCC register block`) is realised in
the host integration build by defining `volatile uint32_t ll_rcc_regs[LL_RCC_REG_COUNT]` in RAM and letting the
driver index it by `LL_RCC_<REG>_OFFSET / 4U`; on the target build the same array stands in for the RCC block
base 0x56028000 (RM0486 p.176). The integration build therefore reaches the same symbol the linker places at
the RCC base, with no additional indirection.

## Clock/reset interactions tested

| Check | Interaction tested | Requirement |
|---|---|---|
| IT-001 | HSI enable then bounded poll, ready flag present in the model -> ready reaches 1U, HSION set | SWR-001, SWR-005, SWR-006 |
| IT-002 | same poll with the flag never set -> loop ends, no ready, HSION still set (no rollback by the LL) | SWR-001, SWR-005, SWR-006 |
| IT-003 | HSE enable then bounded poll with no ready flag -> not ready, HSEON set | SWR-003, SWR-007, SWR-008 |
| IT-004 | HSE ready set -> HSE ready 1U while HSI ready stays 0U (no cross-talk between oscillators) | SWR-007, SWR-008, SWR-005 |
| IT-005..IT-007 | GPDMA1 clock enable -> reset assert -> reset release, with the clock staying enabled across the reset | SWR-013, SWR-015, SWR-019, SWR-020 |
| IT-008..IT-010 | GPDMA1 and ADC12 in the same enable register: enable/enable, disable of one, reset release of the other | SWR-009..SWR-016, SWR-018 |
| IT-011..IT-012 | cross-group: RCC_CR, RCC_AHB1ENR and RCC_AHB1RSTR operations preserve each other's bits | SWR-021, SWR-022, SWR-023 |
| IT-013 | HAL-like end-to-end init: HSI start (bounded poll) -> clock enable -> reset assert -> reset release | SWR-001, SWR-005, SWR-013, SWR-019, SWR-020 |

## Robustness, fault propagation, timing/resource budgets

- Bounded polling by the caller: the LL contains no loop, no timeout and no delay (SWE.2 section 4); the
  integration test therefore owns the bound (`IT_BOUND = 64U`) and both outcomes are checked - the poll that
  reaches ready inside the bound (IT-001, IT-013) and the poll that ends without ready when the ready flag is
  never set (IT-002, IT-003). The second case is the fault path a HAL timeout builds on; the LL must not
  spin and must not undo the enable it performed, which is what IT-002/IT-003 assert.
- Fault propagation: the LL has no error return and no status channel (SWE.2 section 4), so no fault is
  swallowed inside the driver - the only observable failure is "ready query still 0U after the caller's
  bound", which the test detects through the public interface. No LL function can block or retry.
- Timing: each LL function performs exactly one register read-modify-write or one register read; the
  integration checks are therefore deterministic in call order and hold no timing assumption. Real clock-tree
  settle time is hardware behaviour and is not modelled here (see Simulation vs target limitations).
- Resource budgets (`.forge-run/manifest.json`: flash <= 4096 B, static RAM <= 64 B, stack <= 128 B), measured
  on `target-cm55-gcc`: `text = 288 B`, `data = 0 B`, `bss = 0 B` (object-level, not linked image), so flash is
  288 B of the 4096 B budget and the LL contributes 0 B of static RAM (`ll_rcc_regs` is owned by the linker /
  host test, SWE.2 section 5, SWR-026). Per-function stack frames: 16 functions, maximum frame 0 B
  (`-fstack-usage`, scope "per-function frames; call-graph worst case not computed"), inside the 128 B budget
  (SWR-027).
- Host integration coverage (`forge-tests-mcp.llvm_coverage`, level integration): line 86.25 %, branch 100.0 %,
  function 93.75 %, region 98.15 %; MC/DC not computed by this tool (reported as None, not claimed).

## Results

Host integration (`forge-tests-mcp.run_integration`, clang 19.1.7, self-checking tests):

    {"status":"PASS","summary":"integration: 1 passed, 0 failed (HOST)"}

Per-check output of the integration program (13 checks, all PASS):

    IT-001 PASS
    IT-002 PASS
    IT-003 PASS
    IT-004 PASS
    IT-005 PASS
    IT-006 PASS
    IT-007 PASS
    IT-008 PASS
    IT-009 PASS
    IT-010 PASS
    IT-011 PASS
    IT-012 PASS
    IT-013 PASS

Renode target run (`forge-sim-mcp.run_renode`, Renode v1.17.0, cortex-m55, platform
`forge-stm32n6-rcc-min (CPU+NVIC+AXISRAM+behavioural RCC)`), target tests of
`software/tests/target/test_rcc_target.c` and `software/tests/target/test_rcc_target_timeout.c`:

    {"status":"PASS","summary":"renode cortex-m55: 36 checks passed, 0 failed (2 images; behavioural RCC model)"}

Provenance of the results quoted above (tool invocation ids and artifact hashes):

| Result | Invocation | Artifact sha256 |
|---|---|---|
| Host integration | inv-a63e5db0be8d4dda | 2d381db784603dcfe399cfcec5a0de6fc405a1f45c634ce96ae243ce4edf16ee |
| Integration coverage | inv-d880075352714b43 | 1afcc2a0fb2c6755c4f9724d72fc7d6d4fb50bc66c83a4f727ee3a741c4d738b |
| Renode target | inv-7ce5f2965ca64b02 | 946d594b7bb185d401e8576e839501c1c86294edb0394a4b34b6957910165218 |
| ELF size | inv-c4c9a214999e4a79 | 5ddb05e29eb07b72b8b245c3a6a2eddd655fb1f135a43299fce1cdc121adc211 |
| Stack usage | inv-91581205cd1c4618 | bd8073e56ecf5cd23b2a2539bb2b5fad51ec888b62ccbcdf342a26f976f77548 |

## Simulation vs target limitations

- Execution environment: a simulated Arm Cortex-M55 (Renode v1.17.0) with a behavioural RCC model
  (`forge-stm32n6-rcc-min`: CPU + NVIC + AXISRAM + behavioural RCC). The register words are observed in
  memory; the model reproduces the register semantics of RM0486 chapter 14 as encoded in the driver's
  generated definitions, not the silicon.
- No clock-tree timing: oscillator start-up time, ready-flag latency, PLL lock timing and clock-switch
  settling are not modelled. Any statement about how long a flag needs to become ready, and therefore about
  the correct caller deadline, is outside what this evidence supports.
- No security filtering: RCC security/privilege attributes (RIF/secure register access) are not modelled, so
  the runs give no evidence about accesses that silicon could reject.
- No silicon verification: `target.silicon_revision` is UNSPECIFIED in the work-order manifest, and this work
  order allocates no safety claim (`safety_allocation: OUT_OF_SCOPE: QM development`). The Renode results are
  simulated target evidence, not silicon evidence; `silicon_verified` is false in the tool provenance.
- Size measurements are object-level (`objects = 2`, "object-level, not linked image") and the stack report
  covers per-function frames only; worst-case call-graph depth is not computed.
- Because the LL is header-only `static inline`, the host and target builds exercise the same source; there is
  no target-only branch that host testing can miss, but the host integration build substitutes RAM for the RCC
  block at 0x56028000.

## Scope exclusions

The work-order scope (`.forge-run/manifest.json`, `scope`) lists as out of scope:

| Excluded interaction | Status |
|---|---|
| HAL API (status codes, parameter checks, timeouts) - work order 0002b | not applicable: excluded by work-order scope |
| PLL configuration | not applicable: excluded by work-order scope |
| Clock tree switching | not applicable: excluded by work-order scope |
| Security/privilege configuration | not applicable: excluded by work-order scope |
| Interrupts | not applicable: excluded by work-order scope |
| Low-power modes | not applicable: excluded by work-order scope |

The architecture carries the same boundary (SWE.2 section 1: "No HAL component, no PLL configuration, no
clock-tree switching and no interrupt handling exists at this architecture level"). The bounded polling used
in the integration sequences is caller-owned test code that stands in for the future HAL, not a HAL
implementation delivered by this work order.

## Open defects

none
