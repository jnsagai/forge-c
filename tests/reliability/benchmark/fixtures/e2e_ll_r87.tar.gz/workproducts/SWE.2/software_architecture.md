# Software architecture

Scope: header-only RCC low-level (LL) driver for the STM32N657X0 (STM32N6x5/x7), register access only.
This architecture is derived from the frozen SWE.1 baseline BL-SWE.1-001
(workproducts/SWE.1/software_requirements.md) and from the RM0486 Rev 4 register sections listed in the
Register table. Every hardware fact carries a DOC p.N citation. This work order is LL only; the HAL layer
(status codes, parameter checks, timeouts, polling loops) is out of scope and is built by a later HAL work
order (WO-0002b) on top of this LL.

## 1. Components

| Component | Kind | Files | Responsibility |
|---|---|---|---|
| `stm32n6xx_ll_rcc` | LL module, header-only, `static inline` | `software/ll/stm32n6xx_ll_rcc.h` | Single register-level access to the RCC block: HSI/HSE oscillator enable/disable and ready queries (SWR-001..SWR-008), peripheral clock enable/disable/is-enabled and reset assert/release for the AHB1 peripherals ADC12 and GPDMA1 (SWR-009..SWR-020), with read-modify-write that preserves all other bits (SWR-021..SWR-023). |
| RCC register block | Hardware | memory-mapped, base 0x56028000 (RM0486 p.176) | Holds RCC_CR, RCC_SR, RCC_AHB1RSTR and RCC_AHB1ENR, addressed by offset from the block base. |

There is exactly one software component in this work order. No HAL component, no PLL configuration, no
clock-tree switching and no interrupt handling exists at this architecture level (work-order scope,
`.forge-run/manifest.json`). The LL has no state, no initialization call and no destructor: every LL
function is a pure register access (SWR-024).

Component dependency (static view, `workproducts/SWE.2/architecture_static.puml`):

`Caller -> stm32n6xx_ll_rcc -> RCC register block (0x56028000)`

The caller (application or the future HAL work order) owns polling, timeouts and critical sections; the LL
owns only the single register access.

## 2. Register access

- The RCC register block is represented by one externally defined array of 32-bit words:

  `extern volatile uint32_t ll_rcc_regs[];`

  The array is placed at the RCC base address 0x56028000 by the linker (one linker symbol at the block
  base, RM0486 p.176). On the host test build the array is defined in RAM by the test, which observes the
  register bits exactly as the requirements' verification steps describe
  (workproducts/SWE.1/software_requirements.md).
- Every register is addressed as `ll_rcc_regs[LL_RCC_<REG>_OFFSET / 4U]`, where `LL_RCC_<REG>_OFFSET` is
  the byte offset of the register inside the RCC block (see the Register table). No integer-to-pointer
  cast, no pointer arithmetic and no hard-coded absolute address appears in the driver: all addressing is
  array indexing by offset/4.
- All accesses are `volatile` 32-bit reads or writes, so the compiler cannot merge, reorder or elide them.
- Writes are read-modify-write:

  1. read the whole register word from `ll_rcc_regs[offset/4U]`;
  2. change only the target bit (logical OR with the bit mask for set/reset-assert, logical AND with the
     inverted mask for clear/reset-release);
  3. write the word back.

  This preserves every other bit of the register (SWR-021, SWR-022, SWR-023). Bit masks are written as
  `(1UL << LL_RCC_<REG>_<BIT>_POS)` with a named position constant, so no magic bit numbers appear in the
  implementation.
- Queries are a single read of the register word plus a mask-and-compare using C boolean operators only
  (`((reg & mask) != 0U) ? 1U : 0U`), never a direct mask value, because the requirement fixes the return
  value to exactly 1U or 0U (SWR-005..SWR-008, SWR-011, SWR-012, SWR-015, SWR-016).
- The generated set/clear alias registers (for example RCC_CR HSIONS/HSIONC and RCC_AHB1ENR
  ADC12ENS/ADC12ENC, RM0486 p.480, p.575) are not part of the address space reached by this LL: the LL is
  stateless and operates on the base registers, and the requirement set defines the observable effect on
  RCC_CR, RCC_SR, RCC_AHB1ENR and RCC_AHB1RSTR only.
- No LL function writes any register unless it is called: there is no static initialization and no
  constructor, so nothing is written after reset (SWR-024).

## 3. Interfaces

All functions are `static inline` with C linkage, return `void` for actions and `uint32_t` for queries, and
take exactly `(void)` - no parameters, no pointer arguments, no status codes, no error returns
(work-order scope: no parameter checks and no timeouts at LL level).

Save/restore interrupt primitives are not used, because no LL function is a critical section: every
function is exactly one read-modify-write or one read of a single RCC register.

### 3.1 Oscillators (HSI and HSE only)

| Function | Prototype | Effect | Requirement |
|---|---|---|---|
| `LL_RCC_HSI_Enable` | `static inline void LL_RCC_HSI_Enable(void)` | set RCC_CR.HSION (bit 3) | SWR-001 |
| `LL_RCC_HSI_Disable` | `static inline void LL_RCC_HSI_Disable(void)` | clear RCC_CR.HSION (bit 3) | SWR-002 |
| `LL_RCC_HSI_IsReady` | `static inline uint32_t LL_RCC_HSI_IsReady(void)` | 1U if RCC_SR.HSIRDY (bit 3) set, else 0U | SWR-005, SWR-006 |
| `LL_RCC_HSE_Enable` | `static inline void LL_RCC_HSE_Enable(void)` | set RCC_CR.HSEON (bit 4) | SWR-003 |
| `LL_RCC_HSE_Disable` | `static inline void LL_RCC_HSE_Disable(void)` | clear RCC_CR.HSEON (bit 4) | SWR-004 |
| `LL_RCC_HSE_IsReady` | `static inline uint32_t LL_RCC_HSE_IsReady(void)` | 1U if RCC_SR.HSERDY (bit 4) set, else 0U | SWR-007, SWR-008 |

MSI, LSI, LSE and the PLLs have no LL function in this work order (out of scope).

### 3.2 Peripheral clocks (peripherals of the provided RM sections)

| Function | Prototype | Effect | Requirement |
|---|---|---|---|
| `LL_RCC_ADC12_Enable` | `static inline void LL_RCC_ADC12_Enable(void)` | set RCC_AHB1ENR.ADC12EN (bit 5) | SWR-009 |
| `LL_RCC_ADC12_Disable` | `static inline void LL_RCC_ADC12_Disable(void)` | clear RCC_AHB1ENR.ADC12EN (bit 5) | SWR-010 |
| `LL_RCC_ADC12_IsEnabled` | `static inline uint32_t LL_RCC_ADC12_IsEnabled(void)` | 1U if RCC_AHB1ENR.ADC12EN set, else 0U | SWR-011, SWR-012 |
| `LL_RCC_GPDMA1_Enable` | `static inline void LL_RCC_GPDMA1_Enable(void)` | set RCC_AHB1ENR.GPDMA1EN (bit 4) | SWR-013 |
| `LL_RCC_GPDMA1_Disable` | `static inline void LL_RCC_GPDMA1_Disable(void)` | clear RCC_AHB1ENR.GPDMA1EN (bit 4) | SWR-014 |
| `LL_RCC_GPDMA1_IsEnabled` | `static inline uint32_t LL_RCC_GPDMA1_IsEnabled(void)` | 1U if RCC_AHB1ENR.GPDMA1EN set, else 0U | SWR-015, SWR-016 |

### 3.3 Peripheral resets (peripherals of the provided RM sections)

| Function | Prototype | Effect | Requirement |
|---|---|---|---|
| `LL_RCC_ADC12_ForceReset` | `static inline void LL_RCC_ADC12_ForceReset(void)` | set RCC_AHB1RSTR.ADC12RST (bit 5) | SWR-017 |
| `LL_RCC_ADC12_ReleaseReset` | `static inline void LL_RCC_ADC12_ReleaseReset(void)` | clear RCC_AHB1RSTR.ADC12RST (bit 5) | SWR-018 |
| `LL_RCC_GPDMA1_ForceReset` | `static inline void LL_RCC_GPDMA1_ForceReset(void)` | set RCC_AHB1RSTR.GPDMA1RST (bit 4) | SWR-019 |
| `LL_RCC_GPDMA1_ReleaseReset` | `static inline void LL_RCC_GPDMA1_ReleaseReset(void)` | clear RCC_AHB1RSTR.GPDMA1RST (bit 4) | SWR-020 |

Every function above is named for one concrete oscillator or one concrete peripheral; no placeholder,
macro-generated or wildcard entry point exists in the interface.

## 4. Timing and error handling

- No LL function waits, polls, loops or delays. There is no `while` loop, no timeout counter and no delay
  in the LL: each function performs exactly one register read-modify-write or one register read, and
  returns immediately.
- No LL function returns or signals an error: action functions return `void` and query functions return
  only 1U or 0U. Parameter validation, timeout and bus-error handling are HAL responsibilities and belong
  to the later HAL work order.
- Consequence for callers: after `LL_RCC_HSI_Enable` or `LL_RCC_HSE_Enable` the caller bounds its own
  polling loop on `LL_RCC_HSI_IsReady` / `LL_RCC_HSE_IsReady` and applies its own timeout; the LL never
  spins on a ready flag (RM0486 p.480: HSION/HSEON are software-set, p.482: HSIRDY/HSERDY are hardware-set
  in RCC_SR).
- Worst-case execution time of every LL function is a constant: one (or, for a read-modify-write, one read
  followed by one write) 32-bit RCC register access plus a few ALU operations - no branch depends on
  hardware state and no iteration count depends on input.

## 5. Memory and stack budget

| Item | Budget | Architecture allocation |
|---|---|---|
| Flash (code) | <= 4096 B (`.forge-run/manifest.json`) | Header-only `static inline` functions, 14 small functions; no tables, no string constants, no library calls. |
| Static RAM | 0 B for the LL (manifest static-RAM target 64 B) | The LL defines no variable, no state and no constant array. `ll_rcc_regs` is declared `extern` and is owned by the linker/host test, not by the LL; it therefore contributes 0 B of LL static RAM (SWR-026). |
| Stack | <= 128 B (`.forge-run/manifest.json`, SWR-027) | No local variables beyond the single `uint32_t` temporary of a read-modify-write and no call to another function; worst-case stack depth inside an LL function is one word plus the return address. |

No dynamic allocation, no recursion and no indirect calls are used.

## 6. Concurrency and reentrancy

- The LL keeps no state: all state lives in the RCC registers. Every function reads or reads-modifies-writes
  one register word and returns, so the LL is reentrant and free of data races between its own resources.
- A read-modify-write of a shared RCC register word is not atomic. The documented set/clear alias registers
  (for example HSIONS/HSIONC on RCC_CR, RM0486 p.480, and ADC12ENS/ADC12ENC on RCC_AHB1ENR, RM0486 p.575)
  exist on this device for atomic single-bit writes, but they are deliberately not used by this LL, because
  the SWE.1 baseline defines the observable effect on the base registers RCC_CR, RCC_SR, RCC_AHB1ENR and
  RCC_AHB1RSTR and the driver is stateless (see section 2 and the Open points of the SWE.1 baseline).
  Therefore: callers that share an RCC register with another context must serialise access, for example
  inside a critical section (interrupts disabled) that covers the read-modify-write pair.
- Assumption of freedom from interference at architecture level: no LL function is called from an interrupt
  service routine concurrently with an access to the same RCC register word (RCC_CR is written by the HSI/HSE
  functions, RCC_AHB1ENR by the ADC12/GPDMA1 clock functions, RCC_AHB1RSTR by the ADC12/GPDMA1 reset
  functions). Each register word is treated as one exclusive resource; RCC_SR is read-only, so concurrent
  reads of it are harmless.
- The LL never disables interrupts, never takes a lock and never allocates, so no LL call can block, and no
  priority inversion is possible.

## 7. Requirement allocation table

| Requirement | Allocated LL function(s) | Register / bit |
|---|---|---|
| SWR-001 | `LL_RCC_HSI_Enable` | RCC_CR bit 3 (HSION) |
| SWR-002 | `LL_RCC_HSI_Disable` | RCC_CR bit 3 (HSION) |
| SWR-003 | `LL_RCC_HSE_Enable` | RCC_CR bit 4 (HSEON) |
| SWR-004 | `LL_RCC_HSE_Disable` | RCC_CR bit 4 (HSEON) |
| SWR-005 | `LL_RCC_HSI_IsReady` | RCC_SR bit 3 (HSIRDY) |
| SWR-006 | `LL_RCC_HSI_IsReady` | RCC_SR bit 3 (HSIRDY) |
| SWR-007 | `LL_RCC_HSE_IsReady` | RCC_SR bit 4 (HSERDY) |
| SWR-008 | `LL_RCC_HSE_IsReady` | RCC_SR bit 4 (HSERDY) |
| SWR-009 | `LL_RCC_ADC12_Enable` | RCC_AHB1ENR bit 5 (ADC12EN) |
| SWR-010 | `LL_RCC_ADC12_Disable` | RCC_AHB1ENR bit 5 (ADC12EN) |
| SWR-011 | `LL_RCC_ADC12_IsEnabled` | RCC_AHB1ENR bit 5 (ADC12EN) |
| SWR-012 | `LL_RCC_ADC12_IsEnabled` | RCC_AHB1ENR bit 5 (ADC12EN) |
| SWR-013 | `LL_RCC_GPDMA1_Enable` | RCC_AHB1ENR bit 4 (GPDMA1EN) |
| SWR-014 | `LL_RCC_GPDMA1_Disable` | RCC_AHB1ENR bit 4 (GPDMA1EN) |
| SWR-015 | `LL_RCC_GPDMA1_IsEnabled` | RCC_AHB1ENR bit 4 (GPDMA1EN) |
| SWR-016 | `LL_RCC_GPDMA1_IsEnabled` | RCC_AHB1ENR bit 4 (GPDMA1EN) |
| SWR-017 | `LL_RCC_ADC12_ForceReset` | RCC_AHB1RSTR bit 5 (ADC12RST) |
| SWR-018 | `LL_RCC_ADC12_ReleaseReset` | RCC_AHB1RSTR bit 5 (ADC12RST) |
| SWR-019 | `LL_RCC_GPDMA1_ForceReset` | RCC_AHB1RSTR bit 4 (GPDMA1RST) |
| SWR-020 | `LL_RCC_GPDMA1_ReleaseReset` | RCC_AHB1RSTR bit 4 (GPDMA1RST) |
| SWR-021 | all LL functions that write RCC_CR, that is `LL_RCC_HSI_Enable`, `LL_RCC_HSI_Disable`, `LL_RCC_HSE_Enable`, `LL_RCC_HSE_Disable` | RCC_CR bits 3, 4 |
| SWR-022 | all LL functions that write RCC_AHB1ENR, that is `LL_RCC_ADC12_Enable`, `LL_RCC_ADC12_Disable`, `LL_RCC_GPDMA1_Enable`, `LL_RCC_GPDMA1_Disable` | RCC_AHB1ENR bits 4, 5 |
| SWR-023 | all LL functions that write RCC_AHB1RSTR, that is `LL_RCC_ADC12_ForceReset`, `LL_RCC_ADC12_ReleaseReset`, `LL_RCC_GPDMA1_ForceReset`, `LL_RCC_GPDMA1_ReleaseReset` | RCC_AHB1RSTR bits 4, 5 |
| SWR-024 | all LL functions (none of them executes without being called; the LL has no initialization code) | RCC_CR, RCC_SR, RCC_AHB1ENR, RCC_AHB1RSTR |
| SWR-025 | all LL functions (header-only, 14 `static inline` functions, no data) | - |
| SWR-026 | all LL functions (no static RAM allocation; `ll_rcc_regs` is owned by the linker/host test) | - |
| SWR-027 | all LL functions (single `uint32_t` temporary, no nested calls) | - |

No requirement of the baseline is left unallocated, and no LL function exists that is not allocated to a
requirement.

## 8. Register table

The register table below is the only register knowledge SWE.3 may use; SWE.3 implements exactly from this
table. RCC base address 0x56028000 (RM0486 p.176).

| Register | Offset | Bit position(s) | Bit name(s) | Access | RM0486 page |
|---|---|---|---|---|---|
| RCC_CR | 0x000 | 3 | HSION | read/write (read-modify-write) | RM0486 p.480 |
| RCC_CR | 0x000 | 4 | HSEON | read/write (read-modify-write) | RM0486 p.480 |
| RCC_SR | 0x004 | 3 | HSIRDY | read-only | RM0486 p.482 |
| RCC_SR | 0x004 | 4 | HSERDY | read-only | RM0486 p.482 |
| RCC_AHB1RSTR | 0x210 | 4 | GPDMA1RST | read/write (read-modify-write) | RM0486 p.548 |
| RCC_AHB1RSTR | 0x210 | 5 | ADC12RST | read/write (read-modify-write) | RM0486 p.548 |
| RCC_AHB1ENR | 0x250 | 4 | GPDMA1EN | read/write (read-modify-write) | RM0486 p.575 |
| RCC_AHB1ENR | 0x250 | 5 | ADC12EN | read/write (read-modify-write) | RM0486 p.575 |

Bit positions other than those listed above are reserved and are never written with a value of 1 by the
driver: because the write is a read-modify-write of the base register, reserved bits keep their previous
value (SWR-021, SWR-022, SWR-023). RCC_SR is a read-only register; the LL never writes it.
