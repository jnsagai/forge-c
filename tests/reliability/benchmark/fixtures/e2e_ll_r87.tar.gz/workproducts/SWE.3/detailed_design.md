# Detailed design

STM32N6 RCC low-level (LL) driver, header-only implementation
(`software/ll/stm32n6xx_ll_rcc.h`). The register definitions are generated from
RM0486 section files by `forge_factory.inspection.regmap`; the function bodies
are hand-written to the SWE.1 software requirements baseline (BL-SWE.1-001) and
the SWE.2 software architecture baseline (BL-SWE.2-001). See
`software/src/stm32n6xx_ll_rcc.c` for the compile unit that includes the
header-only LL and `software/hal/` for the HAL boundary declared by SWE.2.

All functions read or read-modify-write exactly one 32-bit RCC register word
through the `extern volatile uint32_t ll_rcc_regs[]` register block. Read-modify-
write uses the bit mask `MSK` (set via `|=`, clear via `&=` of the inverted mask)
so that all other bits of the shared register word are preserved (SWR-022,
SWR-023). Readiness/status accessors normalise the register bit to exactly `1U`
(set) or `0U` (clear) (SWR-006, SWR-008, SWR-012, SWR-016). No function contains
a loop, a call, a heap access or a local array.

## Functions

| Function | Purpose | Registers/bits (RM0486 page) | SWR IDs |
|---|---|---|---|
| `LL_RCC_HSI_Enable` | Set the HSI oscillator enable bit (read-modify-write, other bits preserved). | RCC_CR.HSION bit 3 (p.480) | SWR-001, SWR-022 |
| `LL_RCC_HSI_Disable` | Clear the HSI oscillator enable bit. | RCC_CR.HSION bit 3 (p.480) | SWR-002, SWR-023 |
| `LL_RCC_HSI_IsReady` | Return 1U when HSI is ready, 0U otherwise. | RCC_SR.HSIRDY bit 3 (p.482) | SWR-005, SWR-006 |
| `LL_RCC_HSE_Enable` | Set the HSE oscillator enable bit. | RCC_CR.HSEON bit 4 (p.480) | SWR-003, SWR-022 |
| `LL_RCC_HSE_Disable` | Clear the HSE oscillator enable bit. | RCC_CR.HSEON bit 4 (p.480) | SWR-004, SWR-023 |
| `LL_RCC_HSE_IsReady` | Return 1U when HSE is ready, 0U otherwise. | RCC_SR.HSERDY bit 4 (p.482) | SWR-007, SWR-008 |
| `LL_RCC_ADC12_Enable` | Set the ADC1/ADC2 kernel clock enable bit. | RCC_AHB1ENR.ADC12EN bit 5 (p.575) | SWR-009, SWR-022 |
| `LL_RCC_ADC12_Disable` | Clear the ADC1/ADC2 kernel clock enable bit. | RCC_AHB1ENR.ADC12EN bit 5 (p.575) | SWR-010, SWR-023 |
| `LL_RCC_ADC12_IsEnabled` | Return 1U when ADC1/ADC2 clock is enabled, 0U otherwise. | RCC_AHB1ENR.ADC12EN bit 5 (p.575) | SWR-011, SWR-012 |
| `LL_RCC_GPDMA1_Enable` | Set the GPDMA1 clock enable bit. | RCC_AHB1ENR.GPDMA1EN bit 4 (p.575) | SWR-013, SWR-022 |
| `LL_RCC_GPDMA1_Disable` | Clear the GPDMA1 clock enable bit. | RCC_AHB1ENR.GPDMA1EN bit 4 (p.575) | SWR-014, SWR-023 |
| `LL_RCC_GPDMA1_IsEnabled` | Return 1U when GPDMA1 clock is enabled, 0U otherwise. | RCC_AHB1ENR.GPDMA1EN bit 4 (p.575) | SWR-015, SWR-016 |
| `LL_RCC_ADC12_ForceReset` | Assert the ADC1/ADC2 reset bit. | RCC_AHB1RSTR.ADC12RST bit 5 (p.561) | SWR-017, SWR-022 |
| `LL_RCC_ADC12_ReleaseReset` | De-assert the ADC1/ADC2 reset bit. | RCC_AHB1RSTR.ADC12RST bit 5 (p.561) | SWR-018, SWR-023 |
| `LL_RCC_GPDMA1_ForceReset` | Assert the GPDMA1 reset bit. | RCC_AHB1RSTR.GPDMA1RST bit 4 (p.561) | SWR-019, SWR-022 |
| `LL_RCC_GPDMA1_ReleaseReset` | De-assert the GPDMA1 reset bit. | RCC_AHB1RSTR.GPDMA1RST bit 4 (p.561) | SWR-020, SWR-023 |

## Static analysis and MISRA (subset)

MISRA compliance is **not claimed**. Only the Cppcheck MISRA C:2012 addon subset
of the applicable rules was run; undecidable and manual rules require human
review. The results below are reported exactly as the MCP tools returned them.

- `forge-analysis-mcp.cppcheck` (Cppcheck 2.7): status `PASS`, summary
  "cppcheck: 0 general, 0 MISRA rules hit (subset only)". Metrics:
  `general_findings = 0`, `misra_rules_violated = 0`,
  `misra_rules_in_standard_body = 158`, `misra_compliance = "NOT_CLAIMED"`.
  Artifact ref `artifact:sha256:46cf875537687792910117f0a8def6478036ed1511ba1e85ea4f2c7a1b0bead3`.
- `forge-analysis-mcp.clang_analyze` (clang 19.1.7): status `PASS`, summary
  "clang analyzer: 0 diagnostics". Metrics: `files = 1`, `diagnostics = 0`.
  Artifact ref `artifact:sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.
- `forge-docs-mcp.validate_artifact` (`check = swe3_all`): status `PASS`,
  summary "SWE.3 checks: guideline PASS (0), register map PASS, implementation
  PASS". Metrics: `guideline_violations = 0`, `register_map_findings = 0`,
  `implementation_findings = 0`.
  Artifact ref `artifact:sha256:924f375f4fbe82bc8da1012eb68b3cea9a253b9d9772baf17ffe7851d1684e65`.

The rule subset of interest that the code is written to satisfy:

- MISRA C:2012 Rule 15.5 (single point of exit): every accessor assigns a status
  variable and returns it once at the end of the function; no early `return`.
- MISRA C:2012 Rule 11.9 (null pointer constant): the LL contains no pointer
  literal; no `0` is used where a null pointer constant would be required.
- MISRA C:2012 Rule 10.3 / 10.4 (essential type): all masks and bit positions are
  `unsigned` (`U` suffixed) and combined with `uint32_t` operands.
- MISRA C:2012 Rule 2.2 / 17.7: no dead code, no discarded non-void return value.
- No loop, no recursion, no dynamic memory, no `volatile` qualifier removal:
  register access is through the `volatile` block `ll_rcc_regs`.

## Resource usage

Measured with `forge-build-mcp.measure_elf` and `forge-build-mcp.stack_usage` on
profile `target-cm55-gcc` for the compile unit `software/src/stm32n6xx_ll_rcc.c`
(which includes the header-only LL). The architecture budget column is from
`workproducts/SWE.2/software_architecture.md` section 5 (manifest budgets).

| Item | Architecture budget | Measured (compile unit) |
|---|---|---|
| Flash (code / `.text`) | <= 4096 B | 288 B (`text = 288`) |
| Static RAM (`.data` + `.bss`) | 0 B for the LL (manifest target 64 B) | 0 B (`data = 0`, `bss = 0`) |
| Maximum stack frame | <= 128 B | 0 B (`max_frame_bytes = 0`) |

- `measure_elf`: status `PASS`, summary "text=288 data=0 bss=0
  (target-cm55-gcc)"; metrics `flash_bytes = 288`, `ram_bytes = 0`, `text = 288`,
  `data = 0`, `bss = 0`, `objects = 2`, scope "object-level, not linked image".
  Artifact ref `artifact:sha256:5ddb05e29eb07b72b8b245c3a6a2eddd655fb1f135a43299fce1cdc121adc211`.
- `stack_usage`: status `PASS`, summary "max frame 0 B in
  forge_measure_LL_RCC_HSI_Enable (target-cm55-gcc)"; metrics `functions = 16`,
  `max_frame_bytes = 0`, scope "per-function frames; call-graph worst case not
  computed". Artifact ref `artifact:sha256:bd8073e56ecf5cd23b2a2539bb2b5fad51ec888b62ccbcdf342a26f976f77548`.

Note on header-only accounting: the LL is a header-only implementation, so its
`static inline` functions carry no standalone object of their own. Their code and
stack are accounted at the call sites where the compiler materialises the inline
body (the compiler may also share identical bodies). This measurement uses the
compile unit `software/src/stm32n6xx_ll_rcc.c`, which forces materialisation of
all 16 functions, and therefore bounds the code and stack the LL can add to any
caller. The measured 288 B of flash and 0 B of RAM are within the SWE.2 budgets
(4096 B flash, 0 B LL static RAM), and the maximum per-function frame of 0 B is
within the 128 B stack budget (SWR-026, SWR-027).
