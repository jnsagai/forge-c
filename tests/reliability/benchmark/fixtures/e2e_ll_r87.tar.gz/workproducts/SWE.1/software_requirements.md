# Software requirements

Scope: header-only RCC low-level (LL) driver for the STM32N657X0 (STM32N6x5/x7), register access only.
The driver reads and writes the RCC register block through the generated register array `ll_rcc_regs`
(indexed by `LL_RCC_<REG>_OFFSET / 4U`); a host test defines this array in RAM and observes the register bits.
The driver performs no waiting, no polling loops, no timeouts and takes no parameters or error codes;
the separate HAL work order WO-0002b adds waiting, parameter checks and status codes.

- **SWR-001** When the HSI enable function is called, the RCC LL driver shall set RCC_CR.HSION.
  - Source: RM0486 p.480
  - Verification: Host unit test calls the function, then reads ll_rcc_regs[LL_RCC_CR_OFFSET/4U] and checks that bit 3 is 1; pass if bit 3 = 1.
- **SWR-002** When the HSI disable function is called, the RCC LL driver shall clear RCC_CR.HSION.
  - Source: RM0486 p.480
  - Verification: Host unit test pre-sets bit 3 of the register array, calls the function, then checks that bit 3 is 0; pass if bit 3 = 0.
- **SWR-003** When the HSE enable function is called, the RCC LL driver shall set RCC_CR.HSEON.
  - Source: RM0486 p.480
  - Verification: Host unit test calls the function and checks bit 4 of ll_rcc_regs[LL_RCC_CR_OFFSET/4U]; pass if bit 4 = 1.
- **SWR-004** When the HSE disable function is called, the RCC LL driver shall clear RCC_CR.HSEON.
  - Source: RM0486 p.480
  - Verification: Host unit test pre-sets bit 4 of the register array, calls the function, then checks that bit 4 is 0; pass if bit 4 = 0.
- **SWR-005** When the HSI ready query function is called, the RCC LL driver shall return 1U if RCC_SR.HSIRDY is set.
  - Source: RM0486 p.482
  - Verification: Host unit test sets bit 3 of ll_rcc_regs[LL_RCC_SR_OFFSET/4U], calls the query and checks the return value; pass if the return value equals 1U.
- **SWR-006** When the HSI ready query function is called and RCC_SR.HSIRDY is clear, the RCC LL driver shall return 0U.
  - Source: RM0486 p.482
  - Verification: Host unit test clears bit 3 of the register array, calls the query and checks the return value; pass if the return value equals 0U.
- **SWR-007** When the HSE ready query function is called, the RCC LL driver shall return 1U if RCC_SR.HSERDY is set.
  - Source: RM0486 p.482
  - Verification: Host unit test sets bit 4 of ll_rcc_regs[LL_RCC_SR_OFFSET/4U] and checks the return value; pass if the return value equals 1U.
- **SWR-008** When the HSE ready query function is called and RCC_SR.HSERDY is clear, the RCC LL driver shall return 0U.
  - Source: RM0486 p.482
  - Verification: Host unit test clears bit 4 of the register array and checks the return value; pass if the return value equals 0U.
- **SWR-009** When the ADC12 clock enable function is called, the RCC LL driver shall set RCC_AHB1ENR.ADC12EN.
  - Source: RM0486 p.575
  - Verification: Host unit test calls the function and checks bit 5 of ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET/4U]; pass if bit 5 = 1.
- **SWR-010** When the ADC12 clock disable function is called, the RCC LL driver shall clear RCC_AHB1ENR.ADC12EN.
  - Source: RM0486 p.575
  - Verification: Host unit test pre-sets bit 5 of the register array, calls the function, then checks that bit 5 is 0; pass if bit 5 = 0.
- **SWR-011** When the ADC12 clock is-enabled query function is called, the RCC LL driver shall return 1U if RCC_AHB1ENR.ADC12EN is set.
  - Source: RM0486 p.575
  - Verification: Host unit test sets bit 5 of the register array and checks the return value; pass if the return value equals 1U.
- **SWR-012** When the ADC12 clock is-enabled query function is called and RCC_AHB1ENR.ADC12EN is clear, the RCC LL driver shall return 0U.
  - Source: RM0486 p.575
  - Verification: Host unit test clears bit 5 of the register array and checks the return value; pass if the return value equals 0U.
- **SWR-013** When the GPDMA1 clock enable function is called, the RCC LL driver shall set RCC_AHB1ENR.GPDMA1EN.
  - Source: RM0486 p.575
  - Verification: Host unit test calls the function and checks bit 4 of ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET/4U]; pass if bit 4 = 1.
- **SWR-014** When the GPDMA1 clock disable function is called, the RCC LL driver shall clear RCC_AHB1ENR.GPDMA1EN.
  - Source: RM0486 p.575
  - Verification: Host unit test pre-sets bit 4 of the register array, calls the function, then checks that bit 4 is 0; pass if bit 4 = 0.
- **SWR-015** When the GPDMA1 clock is-enabled query function is called, the RCC LL driver shall return 1U if RCC_AHB1ENR.GPDMA1EN is set.
  - Source: RM0486 p.575
  - Verification: Host unit test sets bit 4 of the register array and checks the return value; pass if the return value equals 1U.
- **SWR-016** When the GPDMA1 clock is-enabled query function is called and RCC_AHB1ENR.GPDMA1EN is clear, the RCC LL driver shall return 0U.
  - Source: RM0486 p.575
  - Verification: Host unit test clears bit 4 of the register array and checks the return value; pass if the return value equals 0U.
- **SWR-017** When the ADC12 reset assert function is called, the RCC LL driver shall set RCC_AHB1RSTR.ADC12RST.
  - Source: RM0486 p.548
  - Verification: Host unit test calls the function and checks bit 5 of ll_rcc_regs[LL_RCC_AHB1RSTR_OFFSET/4U]; pass if bit 5 = 1.
- **SWR-018** When the ADC12 reset release function is called, the RCC LL driver shall clear RCC_AHB1RSTR.ADC12RST.
  - Source: RM0486 p.548
  - Verification: Host unit test pre-sets bit 5 of the register array, calls the function, then checks that bit 5 is 0; pass if bit 5 = 0.
- **SWR-019** When the GPDMA1 reset assert function is called, the RCC LL driver shall set RCC_AHB1RSTR.GPDMA1RST.
  - Source: RM0486 p.548
  - Verification: Host unit test calls the function and checks bit 4 of ll_rcc_regs[LL_RCC_AHB1RSTR_OFFSET/4U]; pass if bit 4 = 1.
- **SWR-020** When the GPDMA1 reset release function is called, the RCC LL driver shall clear RCC_AHB1RSTR.GPDMA1RST.
  - Source: RM0486 p.548
  - Verification: Host unit test pre-sets bit 4 of the register array, calls the function, then checks that bit 4 is 0; pass if bit 4 = 0.
- **SWR-021** When the RCC_CR register is written, the RCC LL driver shall change only RCC_CR.HSION and RCC_CR.HSEON and preserve all other bits of RCC_CR.
  - Source: RM0486 p.480
  - Verification: Host unit test pre-loads all register-array words with 0xFFFFFFFF, exercises the HSI/HSE enable and disable functions and checks that every bit outside {3,4} of ll_rcc_regs[LL_RCC_CR_OFFSET/4U] and every other array word keeps its pre-loaded value; pass if all preserved values match.
- **SWR-022** When the RCC_AHB1ENR register is written, the RCC LL driver shall change only RCC_AHB1ENR.GPDMA1EN and RCC_AHB1ENR.ADC12EN and preserve all other bits of RCC_AHB1ENR.
  - Source: RM0486 p.575
  - Verification: Host unit test pre-loads the register array with 0xFFFFFFFF, exercises the ADC12/GPDMA1 clock enable and disable functions and checks that every bit outside {4,5} of ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET/4U] keeps its pre-loaded value; pass if all preserved bits match.
- **SWR-023** When the RCC_AHB1RSTR register is written, the RCC LL driver shall change only RCC_AHB1RSTR.GPDMA1RST and RCC_AHB1RSTR.ADC12RST and preserve all other bits of RCC_AHB1RSTR.
  - Source: RM0486 p.548
  - Verification: Host unit test pre-loads the register array with 0xFFFFFFFF, exercises the ADC12/GPDMA1 reset assert and release functions and checks that every bit outside {4,5} of ll_rcc_regs[LL_RCC_AHB1RSTR_OFFSET/4U] keeps its pre-loaded value; pass if all preserved bits match.
- **SWR-024** While no LL function has been called after reset, the RCC LL driver shall not write any RCC register.
  - Source: RM0486 p.479
  - Verification: Host unit test pre-loads the whole register array with 0xFFFFFFFF, performs no driver call, and checks that every array word still equals its pre-loaded value; pass if all words are unchanged.
- **SWR-025** The RCC LL driver shall use at most 4096 bytes of flash.
  - Source: work-order budget (owner development target)
  - Verification: SWE.6 Robot requirements suite measures the linked object size of the RCC LL functions; pass if the flash size is at most 4096 bytes.
- **SWR-026** The RCC LL driver shall use at most 64 bytes of static RAM.
  - Source: work-order budget (owner development target)
  - Verification: SWE.6 Robot requirements suite reads the static-RAM symbol sizes of the linked image; pass if the RCC LL driver allocates 0 bytes and the measured value is at most 64 bytes.
- **SWR-027** The RCC LL driver shall use at most 128 bytes of stack.
  - Source: work-order budget (owner development target)
  - Verification: SWE.6 Robot requirements suite measures the worst-case stack usage of the RCC LL functions with the stack-size tool; pass if the measured stack usage is at most 128 bytes.

## Open points

- The RCC_CR reset value 0x0000 0008 applies to the reset state of the device; the requirement set does not fix any initial register-array content, because the register array is defined by the host test and follows the RM0486 reset values.
- RM0486 gives no reset value evidence for the AHB1 enable/reset registers other than 0x0000 0000; no requirement depends on other initial values.
- RCC_CR.HSION is set after reset (HSI is the default clock source, RM0486 p.480) while the reset value of RCC_AHB1ENR/RCC_AHB1RSTR is 0x0000 0000 (RM0486 p.575, p.548); the driver is stateless and does not assume either state.
- Security/privilege protection of the oscillator and peripheral bits (HSISEC/HSIPRIV, PERSEC/PERPRIV) is configured outside this driver; the driver performs only the register read-modify-write described above.
- The clock-tree multiplexers and dividers (RCC_CFGR/CKCFGR) and the set/clear alias registers (RCC_CR HSIONS/HSIONC, RCC_AHB1ENR ADC12ENS/ADC12ENC) are not used, because the LL driver is stateless and writes the register array bits directly.
