# SWE.6 Software requirements-based verification report — STM32N6 RCC LL driver

Scope: requirements-based verification of the whole RCC low-level (LL) driver
(`software/ll/stm32n6xx_ll_rcc.h`, header-only `static inline`) against the frozen SWE.1
requirement set SWR-001..SWR-027 (baseline BL-SWE.1-001), on the integrated software built
from the SWE.2/SWE.3/SWE.4/SWE.5 baselines. The verification runs the requirements suite on the
simulated Cortex-M55 target (Renode, behavioural RCC model) plus the host measurements of the
resource requirements. This is software verification against software requirements; it is not a
system-level validation and it carries no silicon claim.

- Work order: WO-0002A-STM32N6-RCC-LL-r87
- Requirement baseline: BL-SWE.1-001 (`workproducts/SWE.1/software_requirements.md`)
- Driver revision: SWE.3 baseline BL-SWE.3-001 (`software/ll/stm32n6xx_ll_rcc.h`)
- Requirements suite: `software/tests/software/test_rcc_requirements.robot` (27 test cases,
  one per SWR) with scenarios `scn_*.c` in the same directory
- Traceability gate: `validate_trace` PASS, 27/27 requirements traced
  (`traceability/requirements_to_tests.csv`)

## Measures and environment

| Item | Value |
|---|---|
| Verification level | Software requirements-based (SWE.6), integrated software |
| Test runner | Robot Framework 6.1 (Python 3.13.13, Linux) |
| Target environment | Renode 1.17.0, simulated Arm Cortex-M55, platform `forge-stm32n6-rcc-min` (CPU + NVIC + AXISRAM + behavioural RCC) |
| Host measurements | `target-cm55-gcc` ELF/flash/static-RAM/stack measurement through the Robot size keywords |
| Result | 27/27 test cases passed, 27/27 requirements verified, 0 failed |
| Silicon verified | false (simulated target only) |

Raw evidence of the run:

- `build/robot/output.xml` — machine-readable results; `<statistics>` reports
  `pass="27" fail="0" skip="0"` for the suite and `pass="1" fail="0"` for every SWR-001..SWR-027.
- `build/robot/log.html` — full execution log (scenario command lines, per-check values).
- `build/robot/report.html` — human-readable summary.
- Tool provenance of the accepted run: `invocation_id inv-293c8bd8d4d44ace`,
  `output_sha256 fb79922680b5c4ff81c8119772f8c2c9e6450fe7eab34ec220aa9d5e7baa3185`,
  artifact ref `artifact:sha256:1b81216a1f69285f6ab6e24b95a065465f8290a1dda7e963b43f6b15ea050911`
  (exit code 0, duration 74868.2 ms, runner Robot Framework 6.1 / Python 3.13.13).
- Traceability gate (re-run after the last test edit): `validate_trace` PASS, 27 requirements,
  27 traced, 27 rows, invocation `inv-f0bc831dffcc487c`.

## SWR → Robot test → result → evidence

The evidence column names the Robot test case (identical to the SWR id, `[Tags] SWR-nnn`), the
scenario that carries the observed check and the TCHECK number, and the result record in
`build/robot/output.xml` / `log.html` (one `<stat pass="1" fail="0">SWR-nnn</stat>` entry per row).

### Normal behaviour (enable/disable/assert/release and ready queries)

| SWR | Robot test | Scenario / TCHECK | Kind | Result | Evidence |
|---|---|---|---|---|---|
| SWR-001 | SWR-001 | scn_osc.c #1 — HSION set | normal | PASS | build/robot/output.xml, log.html |
| SWR-002 | SWR-002 | scn_osc.c #2 — HSION cleared | normal | PASS | build/robot/output.xml, log.html |
| SWR-003 | SWR-003 | scn_osc.c #3 — HSEON set | normal | PASS | build/robot/output.xml, log.html |
| SWR-004 | SWR-004 | scn_osc.c #4 — HSEON cleared | normal | PASS | build/robot/output.xml, log.html |
| SWR-005 | SWR-005 | scn_osc.c #5 — HSI ready returns 1U | normal | PASS | build/robot/output.xml, log.html |
| SWR-007 | SWR-007 | scn_osc.c #7 — HSE ready returns 1U | normal | PASS | build/robot/output.xml, log.html |
| SWR-009 | SWR-009 | scn_ahb1en.c #1 — ADC12EN set | normal | PASS | build/robot/output.xml, log.html |
| SWR-010 | SWR-010 | scn_ahb1en.c #2 — ADC12EN cleared | normal | PASS | build/robot/output.xml, log.html |
| SWR-011 | SWR-011 | scn_ahb1en.c #3 — ADC12 is-enabled returns 1U | normal | PASS | build/robot/output.xml, log.html |
| SWR-013 | SWR-013 | scn_ahb1en.c #5 — GPDMA1EN set | normal | PASS | build/robot/output.xml, log.html |
| SWR-014 | SWR-014 | scn_ahb1en.c #6 — GPDMA1EN cleared | normal | PASS | build/robot/output.xml, log.html |
| SWR-015 | SWR-015 | scn_ahb1en.c #7 — GPDMA1 is-enabled returns 1U | normal | PASS | build/robot/output.xml, log.html |
| SWR-017 | SWR-017 | scn_ahb1rstr.c #1 — ADC12RST set | normal | PASS | build/robot/output.xml, log.html |
| SWR-018 | SWR-018 | scn_ahb1rstr.c #2 — ADC12RST cleared | normal | PASS | build/robot/output.xml, log.html |
| SWR-019 | SWR-019 | scn_ahb1rstr.c #3 — GPDMA1RST set | normal | PASS | build/robot/output.xml, log.html |
| SWR-020 | SWR-020 | scn_ahb1rstr.c #4 — GPDMA1RST cleared | normal | PASS | build/robot/output.xml, log.html |

### Boundary behaviour (flag clear → 0U, register preservation)

| SWR | Robot test | Scenario / TCHECK | Kind | Result | Evidence |
|---|---|---|---|---|---|
| SWR-006 | SWR-006 | scn_never_ready.c `scenario=never_ready` #1 — HSI ready returns 0U | boundary | PASS | build/robot/output.xml, log.html |
| SWR-008 | SWR-008 | scn_never_ready.c `scenario=never_ready` #2 — HSE ready returns 0U | boundary | PASS | build/robot/output.xml, log.html |
| SWR-012 | SWR-012 | scn_ahb1en.c #4 — ADC12 is-enabled returns 0U | boundary | PASS | build/robot/output.xml, log.html |
| SWR-016 | SWR-016 | scn_ahb1en.c #8 — GPDMA1 is-enabled returns 0U | boundary | PASS | build/robot/output.xml, log.html |
| SWR-021 | SWR-021 | scn_cr_preserve.c #1 + #6 — only HSION/HSEON change, all other CR bits kept | boundary (preservation) | PASS | build/robot/output.xml, log.html |
| SWR-022 | SWR-022 | scn_ahb1en_preserve.c #1 + #5 — only GPDMA1EN/ADC12EN change, all other AHB1ENR bits kept | boundary (preservation) | PASS | build/robot/output.xml, log.html |
| SWR-023 | SWR-023 | scn_ahb1rstr_preserve.c #1 + #5 — only GPDMA1RST/ADC12RST change, all other AHB1RSTR bits kept | boundary (preservation) | PASS | build/robot/output.xml, log.html |

SWR-021/022/023 were previously verified only through the generic "all other bits preserved"
check; the named requirement items (the bits the clause names) were not observed by a dedicated
check. TCHECK #6 (scn_cr_preserve.c) and #5 (scn_ahb1en_preserve.c, scn_ahb1rstr_preserve.c) were
added so the observed item is exactly the one named in the clause. This is declared as DEF-001
(kind TEST, target phase SWE.6); no driver behaviour and no expected value was changed.

### Failure and no-write behaviour

| SWR | Robot test | Scenario / TCHECK | Kind | Result | Evidence |
|---|---|---|---|---|---|
| SWR-024 | SWR-024 | scn_no_write.c #1 — no LL call, whole register array unchanged | failure/no-write | PASS | build/robot/output.xml, log.html |
| SWR-025 | SWR-025 | scn_osc.c + `Driver Flash Size Should Be At Most 4096` | resource bound | PASS | build/robot/output.xml, log.html |
| SWR-026 | SWR-026 | scn_osc.c + `Driver Static RAM Should Be At Most 64` | resource bound | PASS | build/robot/output.xml, log.html |
| SWR-027 | SWR-027 | scn_osc.c + `Driver Stack Should Be At Most 128` | resource bound | PASS | build/robot/output.xml, log.html |

SWR-006/SWR-008 use the `never_ready` scenario: the RCC model never raises RCC_SR.HSIRDY/HSERDY,
the caller's bounded loop times out and the query returns 0U — the failure path the future HAL
timeout builds on (matches SWE.5 IT-002/IT-003). SWR-025..SWR-027 check the requirement bound with
"at most N", not an exact count.

No SWR is untested: the traceability gate reports 27/27 requirements traced and the suite runs one
test case per SWR.

## Fault responses and target constraints

- **Fault channel of the LL**: the driver has no parameters, no error return and no status code
  (SWE.2 section 4, `scope` of the manifest). A fault cannot be swallowed inside the driver, so the
  only observable failure is a ready/enabled query that does not reach the expected value within
  the caller's bound. That path is exercised by SWR-006/SWR-008 (ready flag never set) and by the
  negative query checks SWR-012/SWR-016 (enable bit clear).
- **No waiting in the driver**: every LL function performs exactly one register read-modify-write or
  one register read; no loop, timeout or delay exists in the driver, and no test waits on the
  driver. All polling bounds used by the scenarios are caller-owned test code (SWE.5 report,
  "Robustness, fault propagation, timing/resource budgets").
- **Register preservation as the integration contract**: SWR-021..SWR-023 check that a
  read-modify-write of one oscillator/enable/reset register changes only the named bits and leaves
  every other bit at its pre-loaded value; SWR-024 checks that no write happens at all before the
  first call. Together these bound the interference a HAL caller can observe.
- **Resource constraints**: the work-order budgets (`.forge-run/manifest.json`: flash ≤ 4096 B,
  static RAM ≤ 64 B, stack ≤ 128 B) are verified by SWR-025..SWR-027. SWE.5 measured
  `text = 288 B`, `data = 0 B`, `bss = 0 B` (object-level) and a maximum per-function stack frame
  of 0 B for 16 functions; the Robot size keywords confirmed the bounds. The LL contributes no
  static RAM of its own: `ll_rcc_regs` is owned by the linker (target) or by the host test.
- **Target constraints**: the simulated target reproduces the register semantics of RM0486 chapter
  14 as encoded in the driver's generated definitions; oscillator start-up timing, ready-flag
  latency, PLL lock timing, clock-tree switching and security/privilege filtering are not modelled.
  Any conclusion that depends on those is outside this evidence.

## Regressions and defect status

Regression basis: the SWE.4 unit suite (24 checks, `unit: 1 passed, 0 failed (HOST)`), the SWE.5
host integration suite (13 checks, IT-001..IT-013 all PASS) and the SWE.5 Renode target run
(36 checks, 0 failed). The SWE.6 run repeats the requirements-based verification on the
integrated software and found no regression: 27/27 test cases pass and no requirement moved from
pass to fail. The only test-side change of this phase is the added observability checks listed
below.

Defects recorded in `.forge-run/defects`:

| Defect | Kind | Status | Requirement ids | Test files | Effect |
|---|---|---|---|---|---|
| DEF-001 | TEST | DECLARED (own phase, SWE.6; reviewed by the inspector and the human) | SWR-021, SWR-022, SWR-023 | `software/tests/software/scn_cr_preserve.c`, `scn_ahb1en_preserve.c`, `scn_ahb1rstr_preserve.c`, `test_rcc_requirements.robot` (plus `scn_no_write.c` listed as touched-file baseline) | Added TCHECK #6 / #5 / #5 observing the exact bits named in the clauses and the matching `Target Check Should Pass` lines; driver unchanged, expected values unchanged. |

No CODE, ARCHITECTURE, REQUIREMENT or INPUT defect was raised in this phase, and no defect is
REJECTED or open. The residual defect count is zero: DEF-001 is a self-declared test correction in
the author's own phase, not an open product defect.

## Unverified items

Stated accurately, as required:

- **Environment**: the requirements suite ran on the simulated Cortex-M55 target (Renode 1.17.0
  with a behavioural RCC model) plus host measurements of the resource requirements. There is
  **no silicon and no board verification** of this driver; `silicon_verified` is false and the
  work-order manifest records `target.silicon_revision: UNSPECIFIED`. Register-level behaviour on
  real STM32N657X0 silicon (reset values, ready-flag latency, oscillator start-up, bus errors under
  security filtering) is not verified by this report.
- **Safety allocation is out of scope by owner decision** (`safety_allocation: OUT_OF_SCOPE: QM
  development, no safety allocation or safety claims`). This report therefore claims no ASIL, no
  technical/software safety requirement coverage and no safe-state or reaction-time evidence; the
  SWE.1 safety requirement document is informational only for this work order.
- **The HAL is not part of this work order.** Status codes, parameter checks, timeouts and any
  HAL-level error handling belong to work order WO-0002b; the LL-only verification here cannot
  support any HAL-level claim. The bounded polling used by the scenarios is caller-owned test
  code.
- **Out of scope per the work-order scope list** and therefore not verified: PLL configuration,
  clock-tree switching, security/privilege configuration, interrupts and low-power modes. The
  set/clear alias registers (RCC_CR HSIONS/HSIONC, RCC_AHB1ENR ADC12ENS/ADC12ENC) are not used by
  the driver and are not exercised.
- **Modelling limits**: the RCC model is behavioural, not the silicon; oscillator start-up time,
  ready-flag latency and clock settling are not modelled, the model does not enforce real reset
  values and it does not model write-1-to-clear or security-rejected accesses. Size measurements
  are object-level (`objects = 2`, not a linked image) and the stack report covers per-function
  frames only, with the worst-case call-graph depth deliberately not computed (SWE.5 report).
- **Coverage caveat carried from SWE.4/SWE.5**: host unit line coverage is 90.0 % with 100 %
  branch coverage (uncovered lines are header guard/comment/macro lines), host integration line
  coverage is 86.25 % with branch 100 %; MC/DC is not computed by the host toolchain and is
  reported as None, never claimed. All requirement clauses have a passing assertion.
- **Upstream input gaps**: the work-order manifest records the input requirement document as
  `NOT_PROVIDED` with unresolved placeholders (approval, part number revision, HSI contract ids,
  safety allocation, budgets). The budgets used by SWR-025..SWR-027 are the owner-set development
  targets recorded in `.forge-run/manifest.json` (2026-10-15) and are not approved upstream values.
  These gaps are tracked in `traceability/upstream_gaps.md` and are outside the author's authority;
  they are recorded here rather than resolved.
