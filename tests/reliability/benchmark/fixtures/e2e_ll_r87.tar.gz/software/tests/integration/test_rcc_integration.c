/* SWE.5 integration test: LL sequences a HAL will use on top of this driver.
 * Host-only evidence (see workproducts/SWE.5/integration_verification_report.md).
 * Register array defined in RAM; the driver addresses it by offset/4 (SWE.2 section 2). */
#include <stdio.h>
#include <stdint.h>
#include "stm32n6xx_ll_rcc.h"

volatile uint32_t ll_rcc_regs[LL_RCC_REG_COUNT];
static int failures = 0;

#define CHECK(id, cond) do { if (cond) { printf("%s PASS\n", (id)); } \
    else { printf("%s FAIL\n", (id)); failures++; } } while (0)

/* Caller-owned bounds, taken from the work-order budgets convention for the
 * caller's bounded polling (SWE.1: the caller bounds its polling; the LL has
 * no timeout of its own - SWE.2 section 4). */
#define IT_BOUND 64U

static void it_reset_regs(void)
{
    uint32_t i;

    for (i = 0U; i < LL_RCC_REG_COUNT; i++)
    {
        ll_rcc_regs[i] = 0U;
    }
}

/* HAL-like helper: enable HSI and poll the ready query, bounded by the caller.
 * Returns 1U when ready inside the bound, 0U on timeout. The LL itself never
 * polls (SWE.2 section 4). */
static uint32_t hal_like_hsi_start(const uint32_t ready_after)
{
    uint32_t i;
    uint32_t ready;

    LL_RCC_HSI_Enable();
    ready = 0U;
    for (i = 0U; i < IT_BOUND; i++)
    {
        if (LL_RCC_HSI_IsReady() != 0U)
        {
            ready = 1U;
            break;
        }
        /* behavioural model of the hardware ready flag (RM0486 p.482) */
        if ((i + 1U) >= ready_after)
        {
            ll_rcc_regs[LL_RCC_SR_OFFSET / 4U] |= LL_RCC_SR_HSIRDY_MSK;
        }
    }

    return ready;
}

/* IT-001: oscillator enable then bounded poll with the ready flag present in the model. */
static void it_osc_enable_then_ready(void)
{
    uint32_t ready;

    it_reset_regs();
    ready = hal_like_hsi_start(4U);
    CHECK("IT-001", (ready == 1U) &&
          ((ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] & LL_RCC_CR_HSION_MSK) != 0U) &&
          (LL_RCC_HSI_IsReady() == 1U));
}

/* IT-002: the same poll ends without ready when the flag is never set (timeout path). */
static void it_osc_enable_timeout(void)
{
    uint32_t i;
    uint32_t ready;

    it_reset_regs();
    LL_RCC_HSI_Enable();
    ready = 0U;
    for (i = 0U; i < IT_BOUND; i++)
    {
        if (LL_RCC_HSI_IsReady() != 0U)
        {
            ready = 1U;
        }
    }
    CHECK("IT-002", (ready == 0U) &&
          ((ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] & LL_RCC_CR_HSION_MSK) != 0U) &&
          (LL_RCC_HSI_IsReady() == 0U));
}

/* IT-003: HSE uses the same sequence shape and its own registers. */
static void it_hse_enable_timeout(void)
{
    uint32_t i;
    uint32_t ready;

    it_reset_regs();
    LL_RCC_HSE_Enable();
    ready = 0U;
    for (i = 0U; i < IT_BOUND; i++)
    {
        if (LL_RCC_HSE_IsReady() != 0U)
        {
            ready = 1U;
        }
    }
    CHECK("IT-003", (ready == 0U) &&
          ((ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] & LL_RCC_CR_HSEON_MSK) != 0U));

    it_reset_regs();
    LL_RCC_HSE_Enable();
    ll_rcc_regs[LL_RCC_SR_OFFSET / 4U] |= LL_RCC_SR_HSERDY_MSK;
    CHECK("IT-004", (LL_RCC_HSE_IsReady() == 1U) &&
          (LL_RCC_HSI_IsReady() == 0U));
}

/* IT-005: peripheral clock, then reset assert and release (the HAL init order). */
static void it_clock_then_reset_cycle(void)
{
    it_reset_regs();
    LL_RCC_GPDMA1_Enable();
    CHECK("IT-005", LL_RCC_GPDMA1_IsEnabled() == 1U);
    LL_RCC_GPDMA1_ForceReset();
    CHECK("IT-006", (ll_rcc_regs[LL_RCC_AHB1RSTR_OFFSET / 4U] &
                     LL_RCC_AHB1RSTR_GPDMA1RST_MSK) != 0U);
    LL_RCC_GPDMA1_ReleaseReset();
    CHECK("IT-007", ((ll_rcc_regs[LL_RCC_AHB1RSTR_OFFSET / 4U] &
                      LL_RCC_AHB1RSTR_GPDMA1RST_MSK) == 0U) &&
                     (LL_RCC_GPDMA1_IsEnabled() == 1U));
}

/* IT-008: two peripherals in the same enable register do not disturb each other. */
static void it_two_peripherals_same_group(void)
{
    it_reset_regs();
    LL_RCC_GPDMA1_Enable();
    LL_RCC_ADC12_Enable();
    CHECK("IT-008", (LL_RCC_GPDMA1_IsEnabled() == 1U) && (LL_RCC_ADC12_IsEnabled() == 1U));
    LL_RCC_GPDMA1_Disable();
    CHECK("IT-009", (LL_RCC_GPDMA1_IsEnabled() == 0U) && (LL_RCC_ADC12_IsEnabled() == 1U));
    LL_RCC_ADC12_ReleaseReset();
    CHECK("IT-010", (LL_RCC_GPDMA1_IsEnabled() == 0U) && (LL_RCC_ADC12_IsEnabled() == 1U));
}

/* IT-011: operations on different groups preserve each other's bits (SWR-021..SWR-023). */
static void it_cross_group_preservation(void)
{
    uint32_t cr_other;
    uint32_t enr_other;

    it_reset_regs();
    ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = LL_RCC_CR_MSION_MSK | LL_RCC_CR_LSION_MSK;
    ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] = LL_RCC_AHB1ENR_ADC12EN_MSK;
    cr_other = LL_RCC_CR_MSION_MSK | LL_RCC_CR_LSION_MSK;
    enr_other = LL_RCC_AHB1ENR_ADC12EN_MSK;

    LL_RCC_GPDMA1_Enable();
    LL_RCC_ADC12_ForceReset();
    LL_RCC_HSE_Enable();
    LL_RCC_ADC12_Enable();

    CHECK("IT-011", ((ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] & cr_other) == cr_other) &&
                    ((ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] & enr_other) == enr_other));

    LL_RCC_HSI_Disable();
    LL_RCC_GPDMA1_ReleaseReset();
    LL_RCC_ADC12_Disable();

    CHECK("IT-012", ((ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] & cr_other) == cr_other) &&
                    ((ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] & LL_RCC_AHB1ENR_GPDMA1EN_MSK) != 0U) &&
                    (LL_RCC_ADC12_IsEnabled() == 0U));
}

/* IT-013: a full HAL-like init sequence for one peripheral, end to end. */
static void it_hal_like_peripheral_init(void)
{
    uint32_t ready;

    it_reset_regs();
    ready = hal_like_hsi_start(2U);
    LL_RCC_GPDMA1_Enable();
    LL_RCC_GPDMA1_ForceReset();
    LL_RCC_GPDMA1_ReleaseReset();

    CHECK("IT-013", (ready == 1U) &&
                    (LL_RCC_GPDMA1_IsEnabled() == 1U) &&
                    ((ll_rcc_regs[LL_RCC_AHB1RSTR_OFFSET / 4U] &
                      LL_RCC_AHB1RSTR_GPDMA1RST_MSK) == 0U) &&
                    ((ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] & LL_RCC_CR_HSION_MSK) != 0U));
}

int main(void)
{
    it_osc_enable_then_ready();
    it_osc_enable_timeout();
    it_hse_enable_timeout();
    it_clock_then_reset_cycle();
    it_two_peripherals_same_group();
    it_cross_group_preservation();
    it_hal_like_peripheral_init();

    return (failures == 0) ? 0 : 1;
}
