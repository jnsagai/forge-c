#include "stm32n6xx_ll_rcc.h"
#include "forge_target_test.h"

FORGE_MAILBOX_DEFINE;

/* SWR-021: only RCC_CR.HSION (bit 3) and RCC_CR.HSEON (bit 4) may change; all other
 * bits of RCC_CR and every other register-array word must keep the pre-loaded value. */
int main(void)
{
  uint32_t i;
  uint32_t preserved;

  FORGE_TEST_BEGIN();

  for (i = 0U; i < LL_RCC_REG_COUNT; i++)
  {
    ll_rcc_regs[i] = 0xFFFFFFFFU;
  }

  LL_RCC_HSI_Enable();
  LL_RCC_HSI_Disable();
  LL_RCC_HSE_Enable();
  LL_RCC_HSE_Disable();

  /* SWR-021: the two named bits were loaded 1 and are cleared by the disable functions */
  TCHECK(4, (ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] & LL_RCC_CR_HSION_MSK) == 0U);
  TCHECK(5, (ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] & LL_RCC_CR_HSEON_MSK) == 0U);

  preserved = (~(LL_RCC_CR_HSION_MSK | LL_RCC_CR_HSEON_MSK)) & 0xFFFFFFFFU;
  TCHECK(1, (ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] & preserved) == preserved);

  /* all words except RCC_CR and the read-only RCC_SR untouched */
  TCHECK(2, ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] == 0xFFFFFFFFU);
  TCHECK(3, ll_rcc_regs[LL_RCC_AHB1RSTR_OFFSET / 4U] == 0xFFFFFFFFU);

  /* SWR-021: the named requirement items RCC_CR.HSION and RCC_CR.HSEON are observable */
  TCHECK(6, (ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] & (LL_RCC_CR_HSION_MSK | LL_RCC_CR_HSEON_MSK)) == 0U);

  FORGE_TEST_END();
  return 0;
}
