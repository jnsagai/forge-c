#include "stm32n6xx_ll_rcc.h"
#include "forge_target_test.h"

FORGE_MAILBOX_DEFINE;

int main(void)
{
  uint32_t r;

  FORGE_TEST_BEGIN();

  /* SWR-009 / SWR-010: RCC_AHB1ENR.ADC12EN */
  ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] = 0U;
  LL_RCC_ADC12_Enable();
  TCHECK(1, (ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] & LL_RCC_AHB1ENR_ADC12EN_MSK) != 0U);

  ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] = LL_RCC_AHB1ENR_ADC12EN_MSK;
  LL_RCC_ADC12_Disable();
  TCHECK(2, (ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] & LL_RCC_AHB1ENR_ADC12EN_MSK) == 0U);

  /* SWR-011 / SWR-012: ADC12 is-enabled query */
  ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] = LL_RCC_AHB1ENR_ADC12EN_MSK;
  TCHECK(3, (ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] & LL_RCC_AHB1ENR_ADC12EN_MSK) != 0U);
  r = LL_RCC_ADC12_IsEnabled();
  TCHECK(9, r == 1U);

  ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] = 0U;
  TCHECK(4, (ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] & LL_RCC_AHB1ENR_ADC12EN_MSK) == 0U);
  r = LL_RCC_ADC12_IsEnabled();
  TCHECK(10, r == 0U);

  /* SWR-013 / SWR-014: RCC_AHB1ENR.GPDMA1EN */
  ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] = 0U;
  LL_RCC_GPDMA1_Enable();
  TCHECK(5, (ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] & LL_RCC_AHB1ENR_GPDMA1EN_MSK) != 0U);

  ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] = LL_RCC_AHB1ENR_GPDMA1EN_MSK;
  LL_RCC_GPDMA1_Disable();
  TCHECK(6, (ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] & LL_RCC_AHB1ENR_GPDMA1EN_MSK) == 0U);

  /* SWR-015 / SWR-016: GPDMA1 is-enabled query */
  ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] = LL_RCC_AHB1ENR_GPDMA1EN_MSK;
  TCHECK(7, (ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] & LL_RCC_AHB1ENR_GPDMA1EN_MSK) != 0U);
  r = LL_RCC_GPDMA1_IsEnabled();
  TCHECK(11, r == 1U);

  ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] = 0U;
  TCHECK(8, (ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] & LL_RCC_AHB1ENR_GPDMA1EN_MSK) == 0U);
  r = LL_RCC_GPDMA1_IsEnabled();
  TCHECK(12, r == 0U);

  FORGE_TEST_END();
  return 0;
}
