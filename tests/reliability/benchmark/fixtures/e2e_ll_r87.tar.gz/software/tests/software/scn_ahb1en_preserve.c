#include "stm32n6xx_ll_rcc.h"
#include "forge_target_test.h"

FORGE_MAILBOX_DEFINE;

/* SWR-022: only RCC_AHB1ENR.GPDMA1EN (bit 4) and RCC_AHB1ENR.ADC12EN (bit 5) may change;
 * all other bits of RCC_AHB1ENR must keep the pre-loaded value. */
int main(void)
{
  uint32_t i;
  uint32_t preserved;

  FORGE_TEST_BEGIN();

  for (i = 0U; i < LL_RCC_REG_COUNT; i++)
  {
    ll_rcc_regs[i] = 0xFFFFFFFFU;
  }

  LL_RCC_ADC12_Enable();
  LL_RCC_ADC12_Disable();
  LL_RCC_GPDMA1_Enable();
  LL_RCC_GPDMA1_Disable();

  /* SWR-022: both named bits changed to 0 by the disable functions (pre-loaded 1) */
  TCHECK(3, (ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] & LL_RCC_AHB1ENR_ADC12EN_MSK) == 0U);
  TCHECK(4, (ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] & LL_RCC_AHB1ENR_GPDMA1EN_MSK) == 0U);

  preserved = (~(LL_RCC_AHB1ENR_GPDMA1EN_MSK | LL_RCC_AHB1ENR_ADC12EN_MSK)) & 0xFFFFFFFFU;
  TCHECK(1, (ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] & preserved) == preserved);

  /* the reset register word must be untouched by enable/disable functions */
  TCHECK(2, ll_rcc_regs[LL_RCC_AHB1RSTR_OFFSET / 4U] == 0xFFFFFFFFU);

  /* SWR-022: the named requirement items RCC_AHB1ENR.GPDMA1EN and RCC_AHB1ENR.ADC12EN are observable */
  TCHECK(5, (ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] & (LL_RCC_AHB1ENR_ADC12EN_MSK | LL_RCC_AHB1ENR_GPDMA1EN_MSK)) == 0U);

  FORGE_TEST_END();
  return 0;
}
