#include "stm32n6xx_ll_rcc.h"
#include "forge_target_test.h"

FORGE_MAILBOX_DEFINE;

int main(void)
{
  uint32_t r;

  FORGE_TEST_BEGIN();

  /* SWR-001 / SWR-002: RCC_CR.HSION */
  ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = 0U;
  LL_RCC_HSI_Enable();
  TCHECK(1, (ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] & LL_RCC_CR_HSION_MSK) != 0U);

  ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = LL_RCC_CR_HSION_MSK;
  LL_RCC_HSI_Disable();
  TCHECK(2, (ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] & LL_RCC_CR_HSION_MSK) == 0U);

  /* SWR-003 / SWR-004: RCC_CR.HSEON */
  ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = 0U;
  LL_RCC_HSE_Enable();
  TCHECK(3, (ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] & LL_RCC_CR_HSEON_MSK) != 0U);

  ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = LL_RCC_CR_HSEON_MSK;
  LL_RCC_HSE_Disable();
  TCHECK(4, (ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] & LL_RCC_CR_HSEON_MSK) == 0U);

  /* SWR-005 / SWR-006: RCC_SR.HSIRDY (model: SR = CR & 0x00000F1F) */
  ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = LL_RCC_CR_HSION_MSK;
  TCHECK(5, (ll_rcc_regs[LL_RCC_SR_OFFSET / 4U] & LL_RCC_SR_HSIRDY_MSK) != 0U);

  ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = 0U;
  TCHECK(6, (ll_rcc_regs[LL_RCC_SR_OFFSET / 4U] & LL_RCC_SR_HSIRDY_MSK) == 0U);

  /* LL_RCC_HSI_IsReady() shall return 1U when RCC_SR.HSIRDY is set (SWR-005). */
  ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = LL_RCC_CR_HSION_MSK;
  r = LL_RCC_HSI_IsReady();
  TCHECK(9, r == 1U);

  /* LL_RCC_HSI_IsReady() shall return 0U when RCC_SR.HSIRDY is clear (SWR-006). */
  ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = 0U;
  r = LL_RCC_HSI_IsReady();
  TCHECK(10, r == 0U);

  /* SWR-007 / SWR-008: RCC_SR.HSERDY */
  ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = LL_RCC_CR_HSEON_MSK;
  TCHECK(7, (ll_rcc_regs[LL_RCC_SR_OFFSET / 4U] & LL_RCC_SR_HSERDY_MSK) != 0U);

  ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = 0U;
  TCHECK(8, (ll_rcc_regs[LL_RCC_SR_OFFSET / 4U] & LL_RCC_SR_HSERDY_MSK) == 0U);

  /* LL_RCC_HSE_IsReady() shall return 1U when RCC_SR.HSERDY is set (SWR-007). */
  ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = LL_RCC_CR_HSEON_MSK;
  r = LL_RCC_HSE_IsReady();
  TCHECK(11, r == 1U);

  /* LL_RCC_HSE_IsReady() shall return 0U when RCC_SR.HSERDY is clear (SWR-008). */
  ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = 0U;
  r = LL_RCC_HSE_IsReady();
  TCHECK(12, r == 0U);

  FORGE_TEST_END();
  return 0;
}
