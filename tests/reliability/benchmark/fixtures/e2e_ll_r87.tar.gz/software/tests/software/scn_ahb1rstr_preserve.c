#include "stm32n6xx_ll_rcc.h"
#include "forge_target_test.h"

FORGE_MAILBOX_DEFINE;

/* SWR-023: only RCC_AHB1RSTR.GPDMA1RST (bit 4) and RCC_AHB1RSTR.ADC12RST (bit 5) may
 * change; all other bits of RCC_AHB1RSTR must keep the pre-loaded value. */
int main(void)
{
  uint32_t i;
  uint32_t preserved;

  FORGE_TEST_BEGIN();

  for (i = 0U; i < LL_RCC_REG_COUNT; i++)
  {
    ll_rcc_regs[i] = 0xFFFFFFFFU;
  }

  LL_RCC_ADC12_ForceReset();
  LL_RCC_ADC12_ReleaseReset();
  LL_RCC_GPDMA1_ForceReset();
  LL_RCC_GPDMA1_ReleaseReset();

  /* SWR-023: the two named bits were loaded 1 and are cleared by the release functions */
  TCHECK(3, (ll_rcc_regs[LL_RCC_AHB1RSTR_OFFSET / 4U] & LL_RCC_AHB1RSTR_ADC12RST_MSK) == 0U);
  TCHECK(4, (ll_rcc_regs[LL_RCC_AHB1RSTR_OFFSET / 4U] & LL_RCC_AHB1RSTR_GPDMA1RST_MSK) == 0U);

  preserved = (~(LL_RCC_AHB1RSTR_GPDMA1RST_MSK | LL_RCC_AHB1RSTR_ADC12RST_MSK)) & 0xFFFFFFFFU;
  TCHECK(1, (ll_rcc_regs[LL_RCC_AHB1RSTR_OFFSET / 4U] & preserved) == preserved);

  /* the enable register word must be untouched by reset assert/release functions */
  TCHECK(2, ll_rcc_regs[LL_RCC_AHB1ENR_OFFSET / 4U] == 0xFFFFFFFFU);

  /* SWR-023: the named requirement items RCC_AHB1RSTR.GPDMA1RST and RCC_AHB1RSTR.ADC12RST are observable */
  TCHECK(5, (ll_rcc_regs[LL_RCC_AHB1RSTR_OFFSET / 4U] & (LL_RCC_AHB1RSTR_ADC12RST_MSK | LL_RCC_AHB1RSTR_GPDMA1RST_MSK)) == 0U);

  FORGE_TEST_END();
  return 0;
}
