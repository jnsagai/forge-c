#include "stm32n6xx_ll_rcc.h"
#include "forge_target_test.h"

FORGE_MAILBOX_DEFINE;

int main(void)
{
  uint32_t r;

  FORGE_TEST_BEGIN();

  /* scenario=never_ready: RCC_SR always reads 0, so the ready queries return 0U.
   * SWR-006: RCC_SR.HSIRDY is clear; the HSI ready query shall return 0U. */
  ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = LL_RCC_CR_HSION_MSK;
  TCHECK(1, (ll_rcc_regs[LL_RCC_SR_OFFSET / 4U] & LL_RCC_SR_HSIRDY_MSK) == 0U);
  r = LL_RCC_HSI_IsReady();
  TCHECK(3, r == 0U);

  /* SWR-008: RCC_SR.HSERDY is clear; the HSE ready query shall return 0U. */
  ll_rcc_regs[LL_RCC_CR_OFFSET / 4U] = LL_RCC_CR_HSEON_MSK;
  TCHECK(2, (ll_rcc_regs[LL_RCC_SR_OFFSET / 4U] & LL_RCC_SR_HSERDY_MSK) == 0U);
  r = LL_RCC_HSE_IsReady();
  TCHECK(4, r == 0U);

  FORGE_TEST_END();
  return 0;
}
