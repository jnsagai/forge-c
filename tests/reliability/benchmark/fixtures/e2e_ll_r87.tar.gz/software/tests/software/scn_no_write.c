#include "stm32n6xx_ll_rcc.h"
#include "forge_target_test.h"

FORGE_MAILBOX_DEFINE;

/* SWR-024: while no LL function has been called after reset, the driver shall not
 * write any RCC register; the whole array keeps its pre-loaded value. */
int main(void)
{
  uint32_t i;
  uint32_t unchanged;

  FORGE_TEST_BEGIN();

  for (i = 0U; i < LL_RCC_REG_COUNT; i++)
  {
    ll_rcc_regs[i] = 0xFFFFFFFFU;
  }

  /* no driver call at all */

  unchanged = LL_RCC_CR_HSION_MSK;
  for (i = 0U; i < LL_RCC_REG_COUNT; i++)
  {
    unchanged &= ll_rcc_regs[i];
  }

  TCHECK(1, unchanged == LL_RCC_CR_HSION_MSK);

  FORGE_TEST_END();
  return 0;
}
