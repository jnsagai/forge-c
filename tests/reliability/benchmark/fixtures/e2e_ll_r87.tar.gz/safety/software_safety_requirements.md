# Software safety requirements

QM development scope: no software safety requirements are allocated (work-order owner decision)

Rationale (from .forge-run/manifest.json, target.safety_allocation): "OUT_OF_SCOPE: QM development, no
safety allocation or safety claims (owner decision 2026-10-15)".

No software safety requirements are listed. No ASIL, safe-state or technical-safety-requirement input was
provided for this work order (manifest upstream.status = NOT_PROVIDED), and none has been invented here.
If a safety allocation is provided later, this file and the affected SWR IDs in
workproducts/SWE.1/software_requirements.md will be revised.
