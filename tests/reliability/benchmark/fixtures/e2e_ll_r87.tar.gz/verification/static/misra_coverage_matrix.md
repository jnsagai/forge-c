# MISRA C:2012 coverage matrix (generated, deterministic)

- Generated: 2026-10-16T15:52:36.074583Z by forge_factory.inspection.misra_matrix
- Tool: cppcheck MISRA addon `/usr/lib/x86_64-linux-gnu/cppcheck/addons/misra.py` (sha256 a1a41d0eda7c4f68fb097552088698f77ce8e10accb78703086910bb1dbe2e66)
- Latest cppcheck result: PASS - cppcheck: 0 general, 0 MISRA rules hit (subset only)
- Rules automated by the addon: 130/158 main-body rules; the rest need manual review.
- **MISRA compliance is NOT claimed**; directives and undecidable rules are not covered.

| Rule | Automated | Status |
|---|---|---|
| 1.1 | no | not automated - manual review required |
| 1.2 | no | not automated - manual review required |
| 1.3 | no | not automated - manual review required |
| 1.4 | yes | no hit (automated subset) |
| 2.1 | no | not automated - manual review required |
| 2.2 | yes | no hit (automated subset) |
| 2.3 | yes | no hit (automated subset) |
| 2.4 | yes | no hit (automated subset) |
| 2.5 | yes | no hit (automated subset) |
| 2.6 | no | not automated - manual review required |
| 2.7 | yes | no hit (automated subset) |
| 3.1 | yes | no hit (automated subset) |
| 3.2 | yes | no hit (automated subset) |
| 4.1 | yes | no hit (automated subset) |
| 4.2 | yes | no hit (automated subset) |
| 5.1 | yes | no hit (automated subset) |
| 5.2 | yes | no hit (automated subset) |
| 5.3 | no | not automated - manual review required |
| 5.4 | yes | no hit (automated subset) |
| 5.5 | yes | no hit (automated subset) |
| 5.6 | yes | no hit (automated subset) |
| 5.7 | yes | no hit (automated subset) |
| 5.8 | yes | no hit (automated subset) |
| 5.9 | yes | no hit (automated subset) |
| 6.1 | yes | no hit (automated subset) |
| 6.2 | yes | no hit (automated subset) |
| 7.1 | yes | no hit (automated subset) |
| 7.2 | yes | no hit (automated subset) |
| 7.3 | yes | no hit (automated subset) |
| 7.4 | yes | no hit (automated subset) |
| 8.1 | yes | no hit (automated subset) |
| 8.2 | yes | no hit (automated subset) |
| 8.3 | no | not automated - manual review required |
| 8.4 | yes | no hit (automated subset) |
| 8.5 | yes | no hit (automated subset) |
| 8.6 | yes | no hit (automated subset) |
| 8.7 | yes | no hit (automated subset) |
| 8.8 | yes | no hit (automated subset) |
| 8.9 | yes | no hit (automated subset) |
| 8.10 | yes | no hit (automated subset) |
| 8.11 | yes | no hit (automated subset) |
| 8.12 | yes | no hit (automated subset) |
| 8.13 | no | not automated - manual review required |
| 8.14 | yes | no hit (automated subset) |
| 9.1 | no | not automated - manual review required |
| 9.2 | yes | no hit (automated subset) |
| 9.3 | yes | no hit (automated subset) |
| 9.4 | yes | no hit (automated subset) |
| 9.5 | yes | no hit (automated subset) |
| 10.1 | yes | no hit (automated subset) |
| 10.2 | yes | no hit (automated subset) |
| 10.3 | yes | no hit (automated subset) |
| 10.4 | yes | no hit (automated subset) |
| 10.5 | yes | no hit (automated subset) |
| 10.6 | yes | no hit (automated subset) |
| 10.7 | yes | no hit (automated subset) |
| 10.8 | yes | no hit (automated subset) |
| 11.1 | yes | no hit (automated subset) |
| 11.2 | yes | no hit (automated subset) |
| 11.3 | yes | no hit (automated subset) |
| 11.4 | yes | no hit (automated subset) |
| 11.5 | yes | no hit (automated subset) |
| 11.6 | yes | no hit (automated subset) |
| 11.7 | yes | no hit (automated subset) |
| 11.8 | yes | no hit (automated subset) |
| 11.9 | yes | no hit (automated subset) |
| 12.1 | yes | no hit (automated subset) |
| 12.2 | yes | no hit (automated subset) |
| 12.3 | yes | no hit (automated subset) |
| 12.4 | yes | no hit (automated subset) |
| 12.5 | no | not automated - manual review required |
| 13.1 | yes | no hit (automated subset) |
| 13.2 | no | not automated - manual review required |
| 13.3 | yes | no hit (automated subset) |
| 13.4 | yes | no hit (automated subset) |
| 13.5 | yes | no hit (automated subset) |
| 13.6 | yes | no hit (automated subset) |
| 14.1 | yes | no hit (automated subset) |
| 14.2 | yes | no hit (automated subset) |
| 14.3 | no | not automated - manual review required |
| 14.4 | yes | no hit (automated subset) |
| 15.1 | yes | no hit (automated subset) |
| 15.2 | yes | no hit (automated subset) |
| 15.3 | yes | no hit (automated subset) |
| 15.4 | yes | no hit (automated subset) |
| 15.5 | yes | no hit (automated subset) |
| 15.6 | yes | no hit (automated subset) |
| 15.7 | yes | no hit (automated subset) |
| 16.1 | yes | no hit (automated subset) |
| 16.2 | yes | no hit (automated subset) |
| 16.3 | yes | no hit (automated subset) |
| 16.4 | yes | no hit (automated subset) |
| 16.5 | yes | no hit (automated subset) |
| 16.6 | yes | no hit (automated subset) |
| 16.7 | yes | no hit (automated subset) |
| 17.1 | yes | no hit (automated subset) |
| 17.2 | yes | no hit (automated subset) |
| 17.3 | yes | no hit (automated subset) |
| 17.4 | no | not automated - manual review required |
| 17.5 | no | not automated - manual review required |
| 17.6 | yes | no hit (automated subset) |
| 17.7 | yes | no hit (automated subset) |
| 17.8 | yes | no hit (automated subset) |
| 18.1 | no | not automated - manual review required |
| 18.2 | no | not automated - manual review required |
| 18.3 | no | not automated - manual review required |
| 18.4 | yes | no hit (automated subset) |
| 18.5 | yes | no hit (automated subset) |
| 18.6 | no | not automated - manual review required |
| 18.7 | yes | no hit (automated subset) |
| 18.8 | yes | no hit (automated subset) |
| 19.1 | no | not automated - manual review required |
| 19.2 | yes | no hit (automated subset) |
| 20.1 | yes | no hit (automated subset) |
| 20.2 | yes | no hit (automated subset) |
| 20.3 | yes | no hit (automated subset) |
| 20.4 | yes | no hit (automated subset) |
| 20.5 | yes | no hit (automated subset) |
| 20.6 | no | not automated - manual review required |
| 20.7 | yes | no hit (automated subset) |
| 20.8 | yes | no hit (automated subset) |
| 20.9 | yes | no hit (automated subset) |
| 20.10 | yes | no hit (automated subset) |
| 20.11 | yes | no hit (automated subset) |
| 20.12 | yes | no hit (automated subset) |
| 20.13 | yes | no hit (automated subset) |
| 20.14 | yes | no hit (automated subset) |
| 21.1 | yes | no hit (automated subset) |
| 21.2 | yes | no hit (automated subset) |
| 21.3 | yes | no hit (automated subset) |
| 21.4 | yes | no hit (automated subset) |
| 21.5 | yes | no hit (automated subset) |
| 21.6 | yes | no hit (automated subset) |
| 21.7 | yes | no hit (automated subset) |
| 21.8 | yes | no hit (automated subset) |
| 21.9 | yes | no hit (automated subset) |
| 21.10 | yes | no hit (automated subset) |
| 21.11 | yes | no hit (automated subset) |
| 21.12 | yes | no hit (automated subset) |
| 21.13 | no | not automated - manual review required |
| 21.14 | yes | no hit (automated subset) |
| 21.15 | yes | no hit (automated subset) |
| 21.16 | yes | no hit (automated subset) |
| 21.17 | no | not automated - manual review required |
| 21.18 | no | not automated - manual review required |
| 21.19 | yes | no hit (automated subset) |
| 21.20 | yes | no hit (automated subset) |
| 21.21 | yes | no hit (automated subset) |
| 22.1 | no | not automated - manual review required |
| 22.2 | no | not automated - manual review required |
| 22.3 | no | not automated - manual review required |
| 22.4 | no | not automated - manual review required |
| 22.5 | yes | no hit (automated subset) |
| 22.6 | no | not automated - manual review required |
| 22.7 | yes | no hit (automated subset) |
| 22.8 | yes | no hit (automated subset) |
| 22.9 | yes | no hit (automated subset) |
| 22.10 | yes | no hit (automated subset) |
